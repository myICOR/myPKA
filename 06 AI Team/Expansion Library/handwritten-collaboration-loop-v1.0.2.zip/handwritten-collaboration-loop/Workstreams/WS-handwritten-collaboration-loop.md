---
ws_id: WS-<NNN>
title: Handwritten Collaboration Loop
status: active
owner: <ORCHESTRATOR_AGENT>
version: '1.0'
created: '<INSTALL_DATE>'
last_updated: '<INSTALL_DATE>'
last_updated_by: <PRIMARY_CAPTURE_AGENT>
---

# WS-<NNN> - Handwritten Collaboration Loop

## Installation note

This Workstream was installed by the **Handwritten Collaboration Loop Expansion Pack** on `<INSTALL_DATE>`. The user's LLM assigned `WS-<NNN>` by picking the next available number in `Team Knowledge/Workstreams/`. Placeholders in angle brackets (`<PRIMARY_CAPTURE_AGENT>`, `<UI_DESIGN_AGENT>`, etc.) were resolved at install time from the team's agent roster and from `.handwritten-loop.yaml`.

The classifier table in §4 ships with generic role labels. The user's LLM **may amend** it to match the team's actual specialist roster — add rows for new shapes of raw input, retarget routing when a more specialized agent exists, or drop rows for shapes the team doesn't capture. The pipeline structure in §2 (classify → route → optional gate → archive → mirror regen) is the SHAPE that transfers across teams and should not be edited at install time.

Paths are read from `.handwritten-loop.yaml` at the myPKA root:
- `<TEAM_INBOX_PATH>` — where the user's app drops inbound artifacts.
- `<NEEDS_FEEDBACK_PATH>` — where the team drops outbound PDFs for the user to annotate.

Both paths may be inside the myPKA tree (Mode A) or in an external app sandbox (Mode B). The Workstream behaves identically either way; only the scan target differs.

---

- **Type:** Workstream — a multi-agent composition that codifies the bidirectional PDF workflow between the user (handwriting app + tablet) and the team. Inbound (user → team) is classify-then-route; outbound (team → user) is Deliverable-gated review.
- **Owners:** `<ORCHESTRATOR_AGENT>` (classification, routing, end-of-day discipline), `<PRIMARY_CAPTURE_AGENT>` (raw_input capture + journal-shaped routing), `<DATABASE_AGENT>` (raw_input doc_type schema + `mypka.db` regen if installed), `<DESIGN_SYSTEM_AGENT>` (folder convention authority + lock convention), `<INFOGRAPHIC_AGENT>` (PDF render of outbound Deliverables), `<AUTOMATION_AGENT>` (future watcher integration — out of scope for v1).
- **References:** `[[GL-001-file-naming-conventions]]` raw-footage section, `[[GL-002-frontmatter-conventions]]` §"Raw inputs" + §"Cross-entity field: `linked_raw_inputs`", `[[GL-028-deliverable-formats]]` (or local equivalent) handwritten-PDF section, `[[WS-003-install-an-expansion]]`.
- **Trigger phrases (pattern-match, not literal):** "process the inbox", "I dropped a PDF", "annotated PDF came back", "scan the inbox folders", "what's in <TEAM_INBOX_PATH>", "what's in Needs Feedback", session-start scan of the two configured folders.

## 1. What this Workstream does

This Workstream is the two-direction PDF workflow between the user (handwriting app + tablet) and the team. The user drops handwritten artifacts — sketches, meeting notes, strategy ideas, voice-memo transcriptions — into `<TEAM_INBOX_PATH>`; the team picks them up, classifies them, routes them to the right specialist, and files the source PDF into `PKM/raw-footage/`. In the reverse direction, the team renders Deliverable-bound drafts to PDF and places them under the mirrored `<NEEDS_FEEDBACK_PATH>/<YYYY-MM-DD-title>/` folder; the user annotates on tablet with handwriting; the annotated PDF syncs back; `<ORCHESTRATOR_AGENT>` reads the ink (a multimodal LLM reads handwriting natively), extracts the structured decisions, and only after user approval does the Deliverable commit or archive. PDF is the lingua franca because it survives every surface — markdown for canonical storage, PDF for the tablet annotation experience, both queryable in `mypka.db` (if installed) via the `raw_inputs` table and the `linked_raw_inputs` back-pointer on every entity type.

## 2. The sequential pipeline

This is a single sequential pipeline. Not a menu of options. Classify-stage is inbound; user-gate is outbound for Deliverable-bound work.

```
Inbound raw input (user drops via handwriting app into <TEAM_INBOX_PATH>)
  → <ORCHESTRATOR_AGENT> classifies (per §4 table)
  → routes to specialist
      ├─ journal-shaped (meeting note, strategy capture, voice memo) → <PRIMARY_CAPTURE_AGENT>
      ├─ design-shaped (UI / layout / interaction / visual)          → <UI_DESIGN_AGENT>
      └─ strategy-shaped (research-grade, brief-bound)               → <RESEARCH_AGENT>
  → specialist produces output as .md (and optional Deliverable)
  → IF the output is Deliverable-bound:
      → User-gate (user-in-the-loop before commit)
      → <INFOGRAPHIC_AGENT> renders the Deliverable to PDF
      → PDF lands in <NEEDS_FEEDBACK_PATH>/<YYYY-MM-DD-title>/<file>.pdf
      → User annotates on tablet in the handwriting app
      → Annotated PDF syncs back via the app's sync layer
      → <ORCHESTRATOR_AGENT> reads the ink (multimodal read discipline)
      → <ORCHESTRATOR_AGENT> produces structured extract (Decisions / Margin notes verbatim / Strikethroughs / Open questions parked back)
      → ONLY after user approval does the Deliverable commit or archive
  → raw_input PDF moves to PKM/raw-footage/<canonical-subfolder>/YYYY/MM/<slug>.pdf
  → <DATABASE_AGENT> regenerates mypka.db (if the SQLite mirror is installed)
```

Classify (inbound) and user-gate (outbound for Deliverable-bound work) are **sequential stages of the same pipeline**, not alternatives. Every raw input passes through classify. Only outputs that fold into a Deliverable pass through the user-gate; quick captures (a meeting note that becomes a journal entry and that's it) do not need a gate.

## 3. End-of-day rule

> Both `<TEAM_INBOX_PATH>` and `<NEEDS_FEEDBACK_PATH>` are empty at end of day, **IF the work was completed**.

The qualifier matters. The end-of-day-empty target is not a clock-driven force-empty. It is a completion criterion: empty when processing is genuinely done. If a PDF lands in `<TEAM_INBOX_PATH>` at 23:55 and the routing requires a fresh specialist session, the file legitimately rolls to the next day. The rule fires against "completed work that hasn't been moved" — orphans of process, not orphans of clock. The session-start scan (§11 below) catches anything that legitimately rolled and routes it then.

The mirrored subfolders (`<YYYY-MM-DD-title>/`) under `<NEEDS_FEEDBACK_PATH>` are deleted once the last PDF inside them has been processed.

## 4. Classifier rules

`<ORCHESTRATOR_AGENT>` consults this table at the inbound stage. The classification decides which specialist owns the raw input. The classification also decides the `subfolder` value on the `raw_input` frontmatter and the `PKM/raw-footage/<subfolder>/` destination.

| Shape of raw input | What it looks like | Routes to | raw-footage subfolder |
|---|---|---|---|
| **Meeting note** | PDF with handwritten notes, typically headed with date / attendees / topic. | `<PRIMARY_CAPTURE_AGENT>` (writes journal entry under `PKM/Journal/YYYY/MM/` with `linked_raw_inputs:` back-pointer). | `meetings/` |
| **Design sketch** | Wireframe, page/component layout, interaction sketch, visual concept. | `<UI_DESIGN_AGENT>` (or split across UI / interaction / visual specialists if the team has them). | `sketches/` |
| **Strategy idea** | Concept capture, business-model draft, opportunity sketch, framework sketch. | `<RESEARCH_AGENT>` if research-grade brief is the right move; `<PRIMARY_CAPTURE_AGENT>` if it's a capture without research depth. `<ORCHESTRATOR_AGENT>` decides at routing time. | `strategy-ideas/` |
| **Voice memo** | `.m4a` capture or a PDF transcription of one. | `<PRIMARY_CAPTURE_AGENT>` (transcribes if needed, captures the content into the right PKM destination, sets `linked_raw_inputs:` back-pointer). | `voice-memos/` |
| **Raw artifact (anything else)** | Scanned doc, business card, receipt, one-off PDF that doesn't fit the above. | `<PRIMARY_CAPTURE_AGENT>` (captures as-is into the right PKM destination — CRM, Documents, or `_misc/`). | `_misc/` |

When the shape is ambiguous, file into `_misc/` and surface the ambiguity to the user at session close — landing somewhere always beats blocking on classification. `_misc/` files are eligible for later promotion (the capture or database specialist may move them once the type is clear, updating any `linked_raw_inputs:` references).

The user's LLM may amend this table at install time or later — add rows for new shapes, retarget routing when a more specialized agent exists, or drop rows for shapes the team doesn't capture. The five-row default reflects the most common shapes observed in real use.

## 5. Sub-folder convention for `PKM/raw-footage/`

The canonical sub-folder list is `meetings/`, `sketches/`, `strategy-ideas/`, `voice-memos/`, `_misc/`. Date-nested `YYYY/MM/` under each. The list is ratified in the user's local `GL-001-file-naming-conventions` (raw-footage section, installed by the Expansion Pack); this Workstream `[[wikilinks]]` rather than copies, so when GL-001 changes, this Workstream inherits automatically.

## 6. Folder convention for user-facing PDFs (mirrored)

The mirrored-subfolder convention for the outbound direction lives in the user's local `GL-028-deliverable-formats` (or local equivalent) handwritten-PDF section. `<NEEDS_FEEDBACK_PATH>` is configured in `.handwritten-loop.yaml`; in Mode A it sits inside the myPKA tree, in Mode B it sits in the handwriting app's sandbox. The Workstream reads the value from the config file rather than hard-coding either path.

## 7. Structured-extract format (when the orchestrator relays annotated PDFs to specialists)

When `<ORCHESTRATOR_AGENT>` routes an annotated PDF's content to a specialist, the orchestrator produces a **structured extract** — not "go read the PDF." The specialist consumes the structured summary; the annotated PDF itself is appendix/source. The extract template (Decisions, Margin notes verbatim, Strikethroughs, Flow diagrams verified, Open questions parked back to the user) applies to **all** annotated PDFs, not just plan documents. The canonical template lives in the user's local `GL-028-deliverable-formats` handwritten-PDF section.

## 8. Read discipline

`<ORCHESTRATOR_AGENT>` consults the read-discipline checklist in the user's local `GL-028-deliverable-formats` on **every** annotated-PDF read trigger. The discipline covers arrow geometry (process arrow vs. label pointer), multiple-choice overrides by hand-drawn workflow, the verify-before-synthesize rule, the structured-extract format, and the per-read checklist. Read it before reading any annotated PDF.

## 9. Lock convention

While the user has a PDF open on the tablet for annotation, the file name carries an `-IN-REVIEW.pdf` suffix to signal the read-side concurrency guard. `<ORCHESTRATOR_AGENT>`'s session-start scan skips any `<filename>-IN-REVIEW.pdf` file. The lock convention lives in the user's local `GL-028-deliverable-formats` handwritten-PDF section. The lock is the explicit-choice mechanism — the alternative is "accept that mid-edit reads are messy," which produces broken extracts when the user is still mid-annotation.

## 10. Frontmatter contract

The `raw_input` doc_type, its required and optional fields, the processing-status pipeline, and the cross-entity `linked_raw_inputs:` back-pointer all live in the user's local `GL-002-frontmatter-conventions` §"Raw inputs" and §"Cross-entity field: `linked_raw_inputs`". `<DATABASE_AGENT>` owns that schema. Required fields per the canonical v1.x: `slug`, `doc_type: raw_input`, `source`, `raw_format`, `captured_at`, `received_at`, `processing_status`, `subfolder`. The `subfolder` enum values MUST match the canonical sub-folder list (§5 above). Do not invent new fields; if a field is missing, edit GL-002 first.

The bidirectional shape (`raw_input.linked_processed_outputs` ↔ entity `linked_raw_inputs`) is what powers the `v_raw_input_lineage` view in `mypka.db` (if installed) — query "what raw inputs produced this journal entry" and "what entries derived from this PDF" in one shot. The bidirectional pair is the data-integrity rule the SQL view enforces; both sides must be present.

## 11. Manual scan trigger

`<ORCHESTRATOR_AGENT>` scans both `<TEAM_INBOX_PATH>` and `<NEEDS_FEEDBACK_PATH>` at **session start**. No file watcher. No background daemon. Light operational discipline — one `ls` on each folder, then routing per §2. The watcher is parked as a future enhancement owned by `<AUTOMATION_AGENT>`; v1 ships manual-scan.

Mid-session, the scan re-fires implicitly when the user says "I just dropped X in <TEAM_INBOX_PATH>" or "the annotated PDF is back" — both are pattern-match triggers per the trigger-phrases list above.

## 12. Expansion Pack provenance

This Workstream was installed by the Handwritten Collaboration Loop Expansion Pack. The original operational version was authored in Tom Solid's myPKA on 2026-05-27 and proved out across multiple real round-trips before being packaged for distribution. The packaging strips Tom-specific paths, specialist names, and tool choices into the placeholders you see above. The pipeline shape, the classifier table structure, the end-of-day qualifier, and the read-discipline checklist all transfer as-is across teams.

When this installation has battle-tested across 2–3 real round-trips, consider contributing improvements back upstream via the Expansion Pack's upstream-contribution path (see the Expansion Pack README).

## What this Workstream does not do

- Does not auto-launch a watcher or daemon. v1 is manual-scan; auto-watching is future `<AUTOMATION_AGENT>` scope per §11.
- Does not bypass the user's gate on Deliverable-bound work. The user-gate is the canonical commit/archive trigger — no specialist commits a Deliverable without an annotated approval cycle.
- Does not edit the user's local `GL-001`, `GL-002`, or `GL-028` (or local equivalents). Those are the canonical authorities; this Workstream `[[wikilinks]]` to them and inherits changes automatically.
- Does not duplicate the classifier table into any specialist's `AGENTS.md`. Specialists consult this Workstream when an inbound routing arrives; `<ORCHESTRATOR_AGENT>` consults this Workstream when classifying.

---

## Decisions log

| Row ID | Date | Section | Change | Why |
|---|---|---|---|---|
| A1 | `<INSTALL_DATE>` | — | Workstream installed from Handwritten Collaboration Loop Expansion Pack. | Initial install. Placeholders resolved from `.handwritten-loop.yaml` and the team's agent roster. |
