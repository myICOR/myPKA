---
date: 2026-06-15
category: meeting
entry_type: meeting-notes
key_element: work
linked_projects:
  - q3-product-direction
linked_topics:
  - advisory-board
linked_raw_inputs:
  - PKM/raw-footage/meetings/2026/06/2026-06-15-sample-advisory-board.pdf
tags:
  - advisory-board
  - q3-planning
  - sample
---

# Advisory board — Q3 decisions

Sample journal entry produced from a handwritten meeting-note raw input. This is the **downstream side** of the bidirectional pair — its sibling raw_input sidecar lives at `[[2026-06-15-sample-advisory-board]]` and carries the symmetric forward pointer in its `linked_processed_outputs:` array.

Quarterly advisory board today. Four advisors on the call, plus me. We worked through the Q3 product direction, the pricing review, and the hiring plan. Three decisions landed.

The Q3 direction holds — we ship the member-dashboard refresh as the headline feature, with the community surface as the secondary investment. The pricing review surfaced one open thread I want to revisit next week: whether the founder tier is still earning its keep against the upgrade path. The hiring plan: one full-stack engineer, one community lead. Both Q3 starts.

Action items from the board are captured in the project note. The handwritten artifact stays in `PKM/raw-footage/meetings/` for lineage.

## Related

- `[[q3-product-direction]]` — project that owns the action items.
- `[[advisory-board]]` — topic note that tracks the recurring meeting cadence.

## Media

Source artifact: `[[2026-06-15-sample-advisory-board.pdf]]` (the original handwritten PDF lives in raw-footage; see frontmatter `linked_raw_inputs`).
