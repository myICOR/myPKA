---
slug: 2026-05-15-sample-wireframe
doc_type: raw_input
source: pdf-expert-ipad
raw_format: pdf
captured_at: 2026-05-15T14:20:00Z
received_at: 2026-05-15T14:22:33Z
processed_at: 2026-05-16T10:05:00Z
routed_to: <UI_DESIGN_AGENT>
processing_status: processed
linked_processed_outputs:
  - Deliverables/2026-05-16-member-dashboard-mockup/mockup.md
subfolder: sketches
raw_binary_path: PKM/raw-footage/sketches/2026/05/2026-05-15-sample-wireframe.pdf
tags:
  - member-dashboard
  - wireframe
  - ui-sketch
  - sample
---

# Raw input — Member dashboard wireframe (sample)

Sample raw_input sidecar for the Handwritten Collaboration Loop Expansion Pack. This example demonstrates the **design-sketch shape**: a handwritten UI wireframe captured on a tablet, dropped into the inbox the same afternoon, classified by the orchestrator as `sketches/`, and routed to the UI design agent for HTML mockup build.

The artifact itself (the `.pdf` sibling at `raw_binary_path`) would contain a single-page wireframe: a member dashboard layout with a header strip (avatar, name, plan tier), a primary metrics row (three cards), a secondary content area split into "Recent Activity" + "Recommendations," and a sidebar nav. Hand-drawn arrows mark interaction states; margin notes call out responsive breakpoints.

The downstream mockup deliverable at `linked_processed_outputs[0]` carries the symmetric back-pointer in its `linked_raw_inputs` frontmatter — see the paired example at `sample-processed-mockup.md`.

## What this is

Hand-drawn UI wireframe for a member dashboard. Source artifact: `[[2026-05-15-sample-wireframe.pdf]]` (sibling binary).

## Routing history

- `2026-05-15T14:22:33Z` — landed in Send to team via tablet sync.
- `2026-05-15T15:40:00Z` — classified as `sketches/` by `<ORCHESTRATOR_AGENT>`.
- `2026-05-16T10:05:00Z` — `<UI_DESIGN_AGENT>` produced the HTML mockup deliverable; back-pointer written; raw_input archived to `PKM/raw-footage/sketches/2026/05/`.
