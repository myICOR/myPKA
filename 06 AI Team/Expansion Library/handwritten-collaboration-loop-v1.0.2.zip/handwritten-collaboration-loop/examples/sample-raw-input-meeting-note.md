---
slug: 2026-06-15-sample-advisory-board
doc_type: raw_input
source: pdf-expert-ipad
raw_format: pdf
captured_at: 2026-06-15T18:42:00Z
received_at: 2026-06-15T18:45:11Z
processed_at: 2026-06-15T21:10:00Z
routed_to: <PRIMARY_CAPTURE_AGENT>
processing_status: processed
linked_processed_outputs:
  - PKM/Journal/2026/06/2026-06-15-advisory-board-q3-decisions.md
subfolder: meetings
raw_binary_path: PKM/raw-footage/meetings/2026/06/2026-06-15-sample-advisory-board.pdf
tags:
  - advisory-board
  - q3-planning
  - sample
---

# Raw input — Advisory board meeting (sample)

Sample raw_input sidecar for the Handwritten Collaboration Loop Expansion Pack. This example demonstrates the **meeting-note shape**: a handwritten artifact captured on a tablet during a live advisory-board meeting, dropped into the inbox the same evening, classified by the orchestrator as `meetings/`, and routed to the primary capture agent for journal-entry processing.

The artifact itself (the `.pdf` sibling at `raw_binary_path`) would contain handwritten notes from the meeting: date and attendees at the top, agenda items with margin notes, action items captured as the discussion happened, and a few hand-drawn flow diagrams sketching the Q3 product direction. Roughly four pages of ink.

The downstream journal entry at `linked_processed_outputs[0]` carries the symmetric back-pointer in its `linked_raw_inputs` frontmatter — see the paired example at `sample-processed-journal.md`.

## What this is

Handwritten meeting note from a Q3 advisory board session. Source artifact: `[[2026-06-15-sample-advisory-board.pdf]]` (sibling binary).

## Routing history

- `2026-06-15T18:45:11Z` — landed in Send to team via tablet sync.
- `2026-06-15T20:55:00Z` — classified as `meetings/` by `<ORCHESTRATOR_AGENT>`.
- `2026-06-15T21:10:00Z` — `<PRIMARY_CAPTURE_AGENT>` produced the journal entry; back-pointer written; raw_input archived to `PKM/raw-footage/meetings/2026/06/`.
