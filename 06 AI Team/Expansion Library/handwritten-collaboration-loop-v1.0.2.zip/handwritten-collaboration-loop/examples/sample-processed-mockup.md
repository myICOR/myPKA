---
slug: 2026-05-16-member-dashboard-mockup
doc_type: deliverable
title: Member Dashboard — HTML mockup
status: draft-for-review
owner: <UI_DESIGN_AGENT>
created: 2026-05-16
linked_raw_inputs:
  - PKM/raw-footage/sketches/2026/05/2026-05-15-sample-wireframe.pdf
tags:
  - member-dashboard
  - mockup
  - sample
---

# Member dashboard — HTML mockup (sample)

Sample mockup deliverable produced from a handwritten UI sketch raw input. This is the **downstream side** of the bidirectional pair — its sibling raw_input sidecar lives at `[[2026-05-15-sample-wireframe]]` and carries the symmetric forward pointer in its `linked_processed_outputs:` array.

The mockup translates the hand-drawn wireframe into a dark-canonical HTML render: header strip (avatar, name, plan tier), three-card metrics row, two-column secondary area (Recent Activity + Recommendations), left sidebar nav. Interaction states from the sketch arrows are wired as `:hover` and `:focus` styles. Responsive breakpoints from the margin notes are encoded at `768px` and `1280px`.

The companion `notes.md` file (sibling in this deliverable folder) captures interpretation rationale and the seven open questions parked back to the user for the annotation round-trip.

## What this is

HTML mockup rendered from the hand-drawn member-dashboard wireframe. Raw input: see frontmatter `linked_raw_inputs` for the lineage back-pointer.

## Files

- `mockup.html` — the renderable mockup itself.
- `mockup.md` — this file; the markdown companion that documents intent and open questions.
- `notes.md` — interpretation rationale + open questions for the annotation round-trip.

## Open questions parked back to the user

Seven questions captured in `notes.md`. The user annotates the rendered PDF on tablet; the orchestrator reads the ink and produces the structured extract per the Workstream's §7 contract.
