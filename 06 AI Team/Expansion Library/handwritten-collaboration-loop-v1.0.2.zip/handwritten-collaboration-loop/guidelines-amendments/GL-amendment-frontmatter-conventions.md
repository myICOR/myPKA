# Guideline amendment — `[[frontmatter-conventions]]`

This file is an INSTRUCTION for the LLM running the install. The LLM reads it, finds the user's local Guideline matching the slug `frontmatter-conventions`, and applies two amendments:

1. A new entity schema for the `raw_input` doc_type (under `## Entity schemas`).
2. A new cross-entity field section for `linked_raw_inputs` (after the `raw_input` schema).

---

## Preflight

1. **Find the target Guideline.** Search `Team Knowledge/Guidelines/` for any file whose slug matches `frontmatter-conventions`.
2. **If the target doesn't exist:** stop and tell the user:
   > "I couldn't find a Guideline matching the slug `frontmatter-conventions` in your `Team Knowledge/Guidelines/`. This Expansion amends it; it doesn't ship a replacement. Install the base Guideline first, or skip this amendment if you maintain your own equivalent."
3. **If the target already contains a section heading `### Raw inputs - \`PKM/raw-footage/...\``:** stop and tell the user:
   > "Your local `frontmatter-conventions` Guideline already has a Raw inputs schema. This Expansion may already be installed. I'll skip to avoid duplication. Confirm if you want me to overwrite."
4. **Otherwise:** proceed.

---

## Amendment 1 — add the `raw_input` entity schema

Find the `## Entity schemas` section in the target Guideline. After the last entity schema in that section (most user Guidelines end the section with `### News entries` or `### Videos`), insert the following verbatim text.

### Verbatim text to insert

```markdown
### Raw inputs - `PKM/raw-footage/<subfolder>/YYYY-MM-DD-<slug>.md`

The **raw_input** doc_type captures un-processed artifacts you drop into the team's intake pipeline — handwritten notes from any handwriting app, sketches, meeting transcripts, voice memos, screenshots, business-card scans. Each artifact ships as a sidecar `.md` file (frontmatter only or a thin body) alongside the binary it describes (`.pdf`, `.png`, `.m4a`, `.jpg`, `.txt`). The raw binary stays in place under `PKM/raw-footage/<subfolder>/`; the `.md` file holds the structured metadata that lets your LLM classify, route, and process it into one or more downstream entities (journal entries, project notes, topic captures, etc.).

```yaml
---
slug: 2026-05-27-board-meeting-sketch        # required, kebab-case — typically YYYY-MM-DD- prefixed since raw inputs are time-stamped artifacts
doc_type: raw_input                          # required, always literally 'raw_input'
source: pdf-expert-ipad                      # required — pdf-expert-ipad | screenshot | voice-memo | business-card-scan | goodnotes | notability | obsidian | apple-notes | remarkable | other
raw_format: pdf                              # required — pdf | png | jpg | m4a | txt | other
captured_at: 2026-05-27T09:14:00Z            # required, ISO-8601 datetime UTC — when you created the artifact
received_at: 2026-05-27T09:18:42Z            # required, ISO-8601 datetime UTC — when it landed in <TEAM_INBOX_PATH> / raw-footage
processed_at: null                           # nullable, ISO-8601 datetime UTC — when the LLM classified + routed (null until processed)
routed_to: penn                              # nullable — specialist slug the artifact was routed to
processing_status: pending                   # required — pending | classified | processing | processed | archived
linked_processed_outputs:                    # optional, array of vault-relative paths to the .md entries this raw input produced
  - PKM/Journal/2026/05/2026-05-27-board-meeting-decisions.md
subfolder: sketches                          # required — raw-footage sub-folder this archives to. Enum MUST match [[file-naming-conventions]] §10.1 exactly.
raw_binary_path: PKM/raw-footage/sketches/2026/05/2026-05-27-board-meeting-sketch.pdf   # optional but recommended
tags:
  - board
  - q3-planning
---
```

**Required fields:** `slug`, `doc_type` (always literally `raw_input`), `source`, `raw_format`, `captured_at`, `received_at`, `processing_status`, `subfolder`.

**Notes:**
- The raw_input entity is **a metadata sidecar**, not the artifact itself. The binary (`.pdf` / `.png` / `.m4a`) is canonical and lives next to the `.md` under `PKM/raw-footage/<subfolder>/YYYY/MM/`. The `.md` exists so a SQLite mirror (or any indexed query) can answer "what's pending" and "what derived from this PDF."
- `slug` follows the file-naming Guideline: kebab-case, ASCII, hyphens only. For time-stamped raw inputs (most of them), prefix with `YYYY-MM-DD-`.
- `source` enum is the **capture surface** — where the artifact was created. Add new values cautiously and document them in this Guideline.
- `raw_format` enum is the **file format** of the underlying binary. Decoupled from `source` because one source can emit multiple formats.
- `captured_at` vs `received_at`: `captured_at` is when you finished the artifact on the source device (annotation save, recording stop). `received_at` is when the file landed in the raw-footage tree (cloud sync, manual drop, automation pull). Both required because lag between the two surfaces network/sync issues.
- `processed_at` is set by the LLM (or the routed specialist) when classification + routing completes. Stays `null` until then.
- `routed_to` is the slug of the specialist who handled it. Multiple specialists may touch a raw input over its lifetime; latest routing wins this field, full chain in body under `## Routing history`.
- `processing_status` is the canonical pipeline: `pending` → `classified` → `processing` → `processed` → `archived`. Promote linearly; status drops valid for reprocessing but should be noted in the body.
- `linked_processed_outputs` is the **forward pointer** — vault-relative paths to the `.md` entries this raw input produced. Mirrors the back-pointer `linked_raw_inputs` field on the produced entity (see next section).
- `subfolder` matches the immediate child folder under `PKM/raw-footage/`. Enum: `meetings | sketches | strategy-ideas | voice-memos | _misc`. [[file-naming-conventions]] is authoritative.
- `raw_binary_path` is optional but heavily recommended — lets queries find the binary directly without re-walking the filesystem.
- Body section conventions: `## What this is` (one-line description), `## Routing history` (chronological log), `## Notes` (free-form, optional).
- **Indexing in a SQLite mirror (if you have one):** Raw input files surface via a `raw_inputs` table mirroring the frontmatter shape; a `v_raw_input_lineage` view joins `raw_inputs.linked_processed_outputs` ↔ entity `linked_raw_inputs`. Regenerate the mirror after this amendment lands.
```

---

## Amendment 2 — add the `linked_raw_inputs` cross-entity field section

Immediately after the `### Raw inputs` schema you just inserted, add this section:

### Verbatim text to insert

```markdown
### Cross-entity field: `linked_raw_inputs`

`linked_raw_inputs` is an **optional, cross-entity back-pointer** available on **every** entity type this Guideline defines (Person, Organization, Project, Goal, Habit, Topic, Key Element, Document, Journal entry, News entry, Video, and any future entity type). It carries an array of vault-relative paths to the `raw_input` `.md` sidecars that produced or contributed to the entity.

```yaml
linked_raw_inputs:
  - PKM/raw-footage/meetings/2026/05/2026-05-27-board-meeting-sketch.md
  - PKM/raw-footage/voice-memos/2026/05/2026-05-27-post-meeting-debrief.md
```

**Why a path, not a slug:** raw input slugs are not globally unique across subfolders the way the eight entity types are (two different days could both have `daily-debrief` voice memos under `voice-memos/`). The vault-relative path uniquely identifies the sidecar without ambiguity. The SQLite mirror still parses the path to extract slug, subfolder, and date for indexing.

**Bidirectional contract:** for every entry in a `raw_input.linked_processed_outputs` array, the corresponding entity SHOULD carry the reverse pointer in `linked_raw_inputs`. Penn (and any other specialist processing raw inputs) is responsible for writing both sides. The regen script's `v_raw_input_lineage` view assumes the bidirectional shape and will flag asymmetric pairs as a data-quality issue.

**Use it whenever a downstream entity derives meaningful content from a raw artifact** — e.g. a journal entry written from a voice memo, a project note seeded from a meeting sketch, a topic note distilled from a stack of strategy-idea PDFs. Don't use it for incidental references (a journal entry that merely mentions a PDF in prose); reserve it for genuine lineage.
```

---

## Decisions log entry

Append to the target Guideline's `## Decisions log` section (create the section if absent — same shape as the file-naming amendment):

```markdown
| <next-row-id> | <today> | Entity schemas + cross-entity field | Added `raw_input` doc_type schema (required fields: slug, doc_type, source, raw_format, captured_at, received_at, processing_status, subfolder) + cross-entity `linked_raw_inputs:` back-pointer available on every entity type. The bidirectional shape (forward `linked_processed_outputs` on raw_input + back-pointer `linked_raw_inputs` on derived entities) powers lineage queries in any SQLite mirror via the `v_raw_input_lineage` view. | Installed by the Handwritten Collaboration Loop Expansion Pack v1.0.0. The bidirectional handwriting workflow needs a structured metadata layer over the raw binaries it archives; the `raw_input` doc_type is that layer. |
```

---

## Rollback (for `teardown.md`)

To revert:

1. Find and delete the `### Raw inputs` schema section under `## Entity schemas`.
2. Find and delete the `### Cross-entity field: \`linked_raw_inputs\`` section.
3. Remove the Decisions log row.
4. Tell the user: "Reverted the `raw_input` schema and `linked_raw_inputs` field from your `frontmatter-conventions` Guideline. Any existing files using these fields are now schema-orphan but not broken — they'll still parse as YAML; just unrecognized by the Guideline. Decide whether to delete those files (`PKM/raw-footage/**/*.md` sidecars and any `linked_raw_inputs:` keys on entity notes) or keep them as inert data."
