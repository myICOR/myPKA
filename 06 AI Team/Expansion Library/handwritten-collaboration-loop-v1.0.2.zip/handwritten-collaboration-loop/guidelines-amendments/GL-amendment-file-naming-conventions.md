# Guideline amendment — `[[file-naming-conventions]]`

This file is an INSTRUCTION for the LLM running the install. The LLM reads it, finds the user's local Guideline matching the slug `file-naming-conventions`, and applies the amendment described below.

---

## Preflight

1. **Find the target Guideline.** Search `Team Knowledge/Guidelines/` for any file whose slug matches `file-naming-conventions`. The user's filename will look like `GL-NNN-file-naming-conventions.md` (any number — myICOR canonical is `GL-001`, but user numbering may differ).
2. **If the target doesn't exist:** stop and tell the user:
   > "I couldn't find a Guideline matching the slug `file-naming-conventions` in your `Team Knowledge/Guidelines/`. This Expansion amends that Guideline; it doesn't ship a replacement. Either install the base Guideline first, or skip this amendment if you maintain your own equivalent under a different slug."
3. **If the target already contains a section matching the heading `## N. \`PKM/raw-footage/\` sub-folder canonical structure` (any number):** stop and tell the user:
   > "Your local `file-naming-conventions` Guideline already has a `PKM/raw-footage/` sub-folder section. This Expansion may already be installed, or you authored the convention yourself. I'll skip this amendment to avoid duplication. If you want me to overwrite, confirm."
4. **Otherwise:** proceed to the amendment.

---

## The amendment — section to add

Add a new top-level numbered section to the target Guideline. The section number is the next free integer after the highest existing top-level numbered section (e.g. if the user's Guideline ends at `## 9. Forbidden characters in filenames`, the new section is `## 10.`).

Insert the section BEFORE the `## Wiki link conventions` section if it exists, OR before the `## Updates to this Guideline` section, OR at the bottom of the body just above the Decisions log — whichever placement is closest to the top of the closing-matter region of the user's Guideline.

### Verbatim section text (substitute `N` with the actual next free number)

```markdown
## N. `PKM/raw-footage/` sub-folder canonical structure

Raw inputs captured via any handwriting app (PDF Expert, GoodNotes, Notability, Obsidian, reMarkable, Apple Notes, etc.) and other ingest paths land under `PKM/raw-footage/`. The folder is **sub-foldered by capture type**, then date-nested by year and month — same date-nesting shape as `PKM/Journal/` and `PKM/Images/`.

The canonical sub-folder list is **fixed**. New types graduate into this list via an edit to this Guideline; they do not spawn ad-hoc siblings. The fixed list keeps `PKM/raw-footage/` queryable — your LLM's session-start scan, your SQLite mirror (`raw_input.subfolder` enum, [[frontmatter-conventions]]), and your filing routes all assume these exact names.

### N.1 The five sub-folders

| Sub-folder | What lands here |
|---|---|
| `meetings/` | Meeting notes (date + attendees + topics). Handwritten or PDF-rendered. |
| `sketches/` | Design sketches, wireframes, UI mockups, diagrams, whiteboard captures. |
| `strategy-ideas/` | Concept captures, business-model drafts, opportunity sketches, framework drafts. |
| `voice-memos/` | `.m4a` captures or PDF transcriptions of voice memos. |
| `_misc/` | Raw artifacts that don't fit the four canonical types (receipts, contracts, scanned docs, one-offs). **Land here over blocking on classification.** Files in `_misc/` are eligible for later promotion: any specialist may move a `_misc/` file to a canonical sub-folder once the type is clear, and update any `linked_raw_inputs:` references. |

The leading underscore on `_misc/` is deliberate — sorts to the top in most listings, visually signals "not a primary type." This is the only exception to the kebab-case folder rule in §1; the underscore is the bucket marker.

### N.2 Path template

```
PKM/raw-footage/<canonical-subfolder>/YYYY/MM/YYYY-MM-DD-<slug>.<ext>
```

Concrete examples:

- `PKM/raw-footage/meetings/2026/05/2026-05-27-stripe-onboarding-call.pdf`
- `PKM/raw-footage/sketches/2026/05/2026-05-27-graph-view-wireframe.pdf`
- `PKM/raw-footage/strategy-ideas/2026/05/2026-05-27-loop-icp-draft.pdf`
- `PKM/raw-footage/voice-memos/2026/05/2026-05-27-morning-walk-thoughts.m4a`
- `PKM/raw-footage/_misc/2026/05/2026-05-27-amazon-receipt-q2.pdf`

### N.3 No time prefix by default

The default filename carries only the date (`YYYY-MM-DD-<slug>.<ext>`), **not** a `YYYY-MM-DD-HH-MM-<slug>` time-prefixed form. Reasons:

1. Most handwriting / ingest paths do not surface a reliable capture-time. Inferring `HH-MM` from filesystem mtime drifts.
2. Raw captures don't need minute precision the way session-logs do — the slug carries the disambiguation.
3. Consistency with `PKM/Journal/` and `PKM/Images/` (both date-only filenames).

**When multiple captures land same day, same sub-folder, same slug**, use the `-1`, `-2` qualifier from the collision-handling section of this Guideline (`2026-05-27-stripe-call.pdf`, `2026-05-27-stripe-call-2.pdf`) — not a time prefix.

### N.4 Folder creation rule

When a sub-folder's `YYYY/MM/` doesn't exist yet, the writing agent creates it (same rule as Journal / Images / session-logs per the root `AGENTS.md` §5). The five canonical sub-folders themselves (`meetings/`, `sketches/`, `strategy-ideas/`, `voice-memos/`, `_misc/`) ship at scaffold install time — agents do not create new sibling sub-folders under `PKM/raw-footage/`; new types come through a Guideline edit.

### N.5 Cross-references

- [[frontmatter-conventions]] — `raw_input` doc_type and `subfolder` enum field. The enum values MUST match §N.1 exactly: `meetings | sketches | strategy-ideas | voice-memos | _misc`.
- [[deliverable-formats]] §8.2 — reverse direction of the bidirectional PDF workflow. Handwritten artifacts dropped in `<TEAM_INBOX_PATH>` route here.
- [[deliverable-formats]] §8.7 — lock convention for in-review PDFs (the read-side concurrency guard).
- Downstream `.md` files derived from these raw artifacts carry `linked_raw_inputs:` frontmatter pointing back per [[deliverable-formats]] §8.2.
```

---

## Decisions log entry

Append a row to the target Guideline's `## Decisions log` section. If the Decisions log doesn't exist, create it at the bottom of the file with this header:

```markdown
## Decisions log

| Row ID | Date | Section | Change | Why |
|---|---|---|---|---|
```

Then add the row (substitute `N` with the actual section number you used, and `<today>` with today's ISO date):

```markdown
| <next-row-id> | <today> | §N (new) | Added §N `PKM/raw-footage/` sub-folder canonical structure. Five fixed sub-folders: `meetings/`, `sketches/`, `strategy-ideas/`, `voice-memos/`, `_misc/`. Date-nested `YYYY/MM/` under each. Path template `PKM/raw-footage/<canonical-subfolder>/YYYY/MM/YYYY-MM-DD-<slug>.<ext>` — date only, no time prefix; multi-capture same-day uses `-1`, `-2` qualifier. `_misc/` exception to kebab-case rule (underscore as bucket marker). Cross-references [[frontmatter-conventions]] raw_input enum + [[deliverable-formats]] §8.2 reverse direction + §8.7 lock convention. | Installed by the Handwritten Collaboration Loop Expansion Pack v1.0.0. The bidirectional handwriting workflow needs a canonical archive structure for raw artifacts; the five sub-folders cover the capture shapes the workflow classifies. |
```

The `<next-row-id>` is the next free row ID — if the existing log uses `A1, A2, A3`, the new row is `A4`; if it uses different conventions (numeric, date-keyed), match.

---

## Rollback (for `teardown.md`)

To revert this amendment:

1. Find the section you added (`## N. \`PKM/raw-footage/\` sub-folder canonical structure` plus its sub-sections N.1–N.5).
2. Delete the section and its sub-sections.
3. Remove the row you added to the Decisions log.
4. Renumber any subsequent top-level numbered sections IF you inserted §N in the middle of the numbered range (which you should not have done per the placement rule above — it should be at the end of the body).
5. Tell the user: "Reverted the `PKM/raw-footage/` sub-folder convention from your `file-naming-conventions` Guideline. Note: `PKM/raw-footage/` itself and any files in it were NOT touched — your data is preserved. See `teardown.md` for the data-handling step."
