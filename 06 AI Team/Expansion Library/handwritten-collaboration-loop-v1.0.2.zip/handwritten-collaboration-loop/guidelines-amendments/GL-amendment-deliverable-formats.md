# Guideline amendment — `[[deliverable-formats]]`

This file is an INSTRUCTION for the LLM running the install. The LLM reads it, finds the user's local Guideline matching the slug `deliverable-formats`, and adds a new top-level section §8 with three subsections: §8 (placement convention), §8.6 (read discipline), §8.7 (lock convention).

If the user's local `deliverable-formats` Guideline already has §8 or higher-numbered top-level sections, the LLM picks the next free number and renames internal cross-references accordingly. The CONTENT below is what matters; the section number is a placeholder.

---

## Preflight

1. **Find the target Guideline.** Search `Team Knowledge/Guidelines/` for any file whose slug matches `deliverable-formats`.
2. **If the target doesn't exist:** stop and tell the user:
   > "I couldn't find a Guideline matching the slug `deliverable-formats` in your `Team Knowledge/Guidelines/`. This Expansion amends it. Install the base Guideline first, or skip this amendment if you maintain your own equivalent."
3. **If the target already contains a section titled `## N. Tom-facing PDF placement convention (mirrored folders)` OR `## N. Handwritten PDF placement convention (mirrored folders)`** (any number): stop and tell the user the amendment may already be installed; ask before overwriting.
4. **Otherwise:** proceed. Compute the next free top-level number `N` after the highest existing one in the target. Use that as the section number throughout the inserted text. Substitute `<USER_NAME>` with the user's first name from `PKM/.user.yaml` per the root AGENTS.md personalization rule.

---

## The amendment — section to add

Insert at the bottom of the body, just above any closing `## Cross-references` / `## Decisions log` sections.

### Verbatim text to insert (substitute `N` and `<USER_NAME>`)

```markdown
## N. Handwritten PDF placement convention (mirrored folders)

When a Deliverables artifact at `Deliverables/<YYYY-MM-DD-title>/<file>.md` (or any nested file inside the same dated parent folder) needs your annotation on tablet / handwriting device, the rendered PDF lands at the configured `needs_feedback_path` (see `.handwritten-loop.yaml`) under a mirrored subfolder:

```
<needs_feedback_path>/<YYYY-MM-DD-title>/<file>.pdf
```

The subfolder name **mirrors the Deliverables folder name exactly** (including the `YYYY-MM-DD-` date prefix). The PDF filename matches the source markdown filename with the `.pdf` extension. This preserves traceability — when you open your handwriting app and see `<YYYY-MM-DD-title>/`, you immediately know which Deliverables artifact this came from.

### N.1 Forward direction (LLM routes deliverable → handwriting device)

1. Render the PDF per your local report-layout / render-recipe Guideline.
2. Create the mirrored subfolder if it doesn't exist:
   ```
   mkdir -p "<needs_feedback_path>/<YYYY-MM-DD-title>/"
   ```
3. Copy the rendered PDF into the mirrored subfolder with the source markdown's filename + `.pdf`.
4. When a Deliverables folder has MULTIPLE PDFs needing annotation, they all land in the SAME mirrored subfolder. Subfolder structure stays flat — every PDF for that deliverable sits at the top of `<YYYY-MM-DD-title>/`.

### N.2 Reverse direction (you drop handwritten artifacts → LLM routes)

The same mirrored discipline applies in reverse. When you drop a handwritten PDF (annotation, sketch, note) into `team_inbox_path`:

1. Your LLM routes the raw artifact to `PKM/raw-footage/<subfolder>/YYYY/MM/<date>-<slug>.pdf` per [[file-naming-conventions]] §10.
2. Any processed `.md` derived from the raw artifact carries `linked_raw_inputs:` frontmatter pointing back to the raw file:
   ```yaml
   linked_raw_inputs:
     - PKM/raw-footage/meetings/2026/05/2026-05-27-plan-annotation.pdf
   ```
3. The raw PDF stays in `PKM/raw-footage/` as the canonical source; downstream `.md` files link to it, never duplicate its content.

### N.3 End-of-day rule (mandatory, qualified)

Both transient folders MUST be empty at end of day **IF the work was completed**:

- `<needs_feedback_path>` — every PDF has been annotated, processed, and migrated to its canonical home in myPKA.
- `<team_inbox_path>` — every dropped artifact has been routed (raw artifacts to `PKM/raw-footage/<subfolder>/YYYY/MM/`; everything else per your local Team Inbox routing rules).

**The qualifier matters.** The end-of-day-empty target is not a clock-driven force-empty. It is a completion criterion: empty when processing is genuinely done. If a PDF lands in `<TEAM_INBOX_PATH>` at 23:55 and the routing requires a fresh specialist session, the file legitimately rolls to the next day. The rule fires against "completed work that hasn't been moved" — orphans of process, not orphans of clock.

The mirrored subfolders (`<YYYY-MM-DD-title>/`) are deleted once the last PDF inside them has been processed.

### N.4 Why mirrored, not flat

A flat `Needs Feedback/` (every PDF at the root, no subfolders) loses provenance on the tablet. <USER_NAME> opens the handwriting app and sees a long list of orphan filenames with no context. The mirrored convention pays a tiny structural cost (one `mkdir -p`) for high provenance gain: every PDF inherits its Deliverables-folder context via the parent subfolder name. When you annotate `<YYYY-MM-DD-title>/plan.pdf`, the subfolder name tells you this is the plan from the `<YYYY-MM-DD-title>` deliverable, not a stray rendering.

### N.5 Cross-reference into the render flow

Your render specialist (Charta, or equivalent) consults the canonical render recipe in your local report-layout Guideline on EVERY PDF render. When the render target is annotation-bound (delivery to the handwriting device), they ALSO consult this §N for the placement convention. The render itself lives in the Deliverables folder; the COPY lands at the mirrored path. The Deliverables-folder file is the canonical artifact; the copy at `<needs_feedback_path>/` is the device-delivery instance.

### N.6 Reading annotated PDFs — discipline (Larry MUST follow)

The back-half of the bidirectional PDF workflow (§N.2 reverse direction) is the LLM **reading** the handwritten annotations <USER_NAME> returns. The placement convention got the artifact into the LLM's hands; this subsection governs how the LLM interprets the ink **without misreading it**.

The rule fires on every "annotated PDF" trigger — whenever a handwritten PDF lands in `<team_inbox_path>/` or `PKM/raw-footage/` with annotation ink (checkboxes, arrows, margin notes, strikethroughs, flow diagrams) and the LLM is about to translate that ink into a synthesis, a specialist brief, or a next move.

**Pair with §N.7.** Read-discipline (§N.6, this subsection) covers HOW the LLM interprets ink once a file is safe to read. §N.7 covers WHEN a file is safe to read — the lock convention that tells the LLM's session-start scan to skip a file still under <USER_NAME>'s pen. The two subsections are the two halves of the same concurrency safety: §N.7 prevents torn reads (LLM reads a half-annotated PDF mid-device-write); §N.6 prevents misreads (LLM reads a fully-annotated PDF and infers the wrong intent). Both must hold.

#### N.6.1 Arrows are process arrows by default

When handwritten ink draws `X → Y` or `X ← Y`, the default reading is **"X flows into Y"** (flow, sequence, causation, routing) — not **"X is labeled Y"**.

- The flow reading is the stronger, lossier-to-discard reading. The label reading is the weaker, lossier-to-adopt reading. Adopting the weaker reading by default loses information; adopting the stronger reading by default preserves it.
- Only adopt the label-pointer reading if the **spatial context clearly shows a label-pointer** — e.g., a bracket grouping body text + an arrow pointing to a phrase, or an arrow originating from a margin word and pointing into a printed line.
- When uncertain about which reading applies, **describe the arrow geometry verbatim** before interpreting: "Arrow originates at <text-or-element-A>, points toward <text-or-element-B>" — then ask <USER_NAME> for the intended reading.

#### N.6.2 Multiple-choice forms can be overridden by hand-drawn workflow

When <USER_NAME> checks one option AND annotates another with a flow/arrow/note, the annotation is a **workflow refinement of the checked decision**, NOT a conflict or an inconsistency requiring resolution.

- The **checkbox is the root decision** — what <USER_NAME> picked.
- The **additional ink is the exception, the sequence, or the contextual variant** — how the root decision actually plays out in practice.
- The form-of-question may imply "pick one." The annotation overrides the form. The annotation wins.
- **ALWAYS flag the override explicitly** to <USER_NAME>. Never rationalize the override into "two parallel patterns" or "two contexts" — that's the failure mode.

#### N.6.3 Verify before synthesizing

When an annotation **deviates from the form of the question**, the verification step matters more than the synthesis step. Describe what's drawn in detail; ask before interpreting.

- When uncertain about flow direction, **ask <USER_NAME> to confirm BEFORE proposing the next move**. Do not park the uncertainty into the synthesis as "I interpreted this as…" — park it back to <USER_NAME> as a question.
- Template: "I see <verbatim description of ink> on <location>. Reading A: <interpretation 1>. Reading B: <interpretation 2>. Which did you intend?"
- The asking-cost is one round-trip. The misread-cost is a polluted specialist brief that propagates downstream and gets caught (or worse, not caught) much later.

#### N.6.4 Structured-extract format (for relaying to specialists)

When the LLM routes an annotated PDF's content to a specialist for action, it produces a **STRUCTURED EXTRACT** — not "go read the PDF." The specialist receives the structured summary; the annotated PDF itself is appendix/source.

This rule applies to **ALL annotated PDFs from `<needs_feedback_path>/` (or `PKM/raw-footage/` once routed)**, not just plan documents.

**Template:**

```
Annotations summary — <doc-slug> — <date>

Decisions:
  Decision N: Option X (checked) + handwritten flow [describe verbatim]
  Decision M: Option Y (checked) + margin note "<verbatim quote>"

Margin notes (substantive — refine architecture):
  Page N: "<direct quote of handwritten text>"

Strikethroughs / rejections:
  Page N: struck through "<printed text>" — indicates <interpretation, verified>

Flow diagrams drawn:
  Page N: arrow from <origin> → <endpoint>, indicating <verified flow>

Open questions parked back to <USER_NAME>:
  - <question 1>
```

**Rules for the extract:**

- **Verbatim quotes** for margin notes and struck text — no paraphrasing.
- **Verified flows only** — any flow the LLM has NOT verified stays in "Open questions," not in "Flow diagrams drawn."
- **One extract per annotated PDF.**
- **Specialist brief references the extract by path**, not the raw PDF. The PDF is appendix.

#### N.6.5 Checklist (LLM runs on every annotated-PDF read trigger)

1. Open the PDF. Scan every page for ink.
2. For each arrow: describe geometry verbatim → default to **process arrow** reading per §N.6.1.
3. For each checked option that ALSO carries additional ink: flag the override per §N.6.2 → treat checkbox as root + ink as refinement.
4. For any ink that deviates from the form of the question: ask <USER_NAME> to verify BEFORE synthesizing (§N.6.3).
5. Produce the structured extract per §N.6.4.
6. Route the structured extract to the specialist(s). The annotated PDF is appendix/source.

### N.7 Lock convention for in-review PDFs (concurrency guard)

The placement convention (§N.1–§N.4) and the read-discipline (§N.6) assume one invariant: **when the LLM reads a PDF from `<needs_feedback_path>/<YYYY-MM-DD-title>/`, the file is in a stable state — not mid-annotation, not mid-cloud-sync, not half-saved by the handwriting app.** Without a lock, the LLM's session-start scan can race with the device's pen: scan picks up a file at second 14, the next stroke saves at second 15, the scanned bytes are a half-state that never existed as a finished artifact. Reading that file produces nonsense that gets synthesized confidently. §N.7 is the lock that prevents the race.

#### N.7.1 The rule (filename-rename lock)

When <USER_NAME> opens a PDF in `<needs_feedback_path>/<YYYY-MM-DD-title>/<file>.pdf` to annotate, the file is **renamed** from `<file>.pdf` to `<file>-IN-REVIEW.pdf` BEFORE the first stroke. When annotation is complete, it's renamed back to `<file>.pdf`.

The LLM's session-start scan of `<needs_feedback_path>` **SKIPS any file matching the glob `*-IN-REVIEW.pdf`**. These files are off-limits: assumed mid-annotation, processing them would race with the device write. They re-enter the scan window only after the rename-back.

The `-IN-REVIEW` suffix lands BEFORE the `.pdf` extension (not after), keeping the file recognizable as a PDF to handwriting apps and the OS file browser. Suffix is uppercase + hyphen-separated to make it visually distinct in the app's file list.

#### N.7.2 Why rename, not sentinel-file or mtime-quiet-window

Three lock mechanisms were considered. The trade-offs:

| Mechanism | How it works | Why rejected / chosen |
|---|---|---|
| **Filename rename** (chosen) | Rename `<file>.pdf` → `<file>-IN-REVIEW.pdf` on annotation start; rename back on complete. Scan skips `*-IN-REVIEW.pdf`. | Single source of truth (filename IS the lock state). Visible in the app's file list. No second artifact to forget to clean up. One gesture, atomic. |
| **Sentinel file** | Create a sibling `<file>.in-review` (empty file) on start; delete on complete. | Two-step gesture; easy to forget the delete → orphan sentinels mask completed files indefinitely. Apps' file browsers don't ergonomically support creating/deleting siblings. |
| **Mtime quiet-window** | Skip any `<file>.pdf` with `mtime > now - 60s`. No user gesture. | Unreliable across cloud-sync delays. A file finished 10 minutes ago might land at second-0 via deferred push. A file in active edit might appear mtime-quiet because the app batches writes. Heuristic, not state. |

**The chosen mechanism trades a small friction tax (the rename gesture) for a hard concurrency guarantee.**

#### N.7.3 The friction tax (documented honestly)

The rename gesture is friction: 4 extra taps per annotation session (long-press → rename → add suffix; long-press → rename → remove suffix at end). Most handwriting apps do not (as of 2026) support an "on-open auto-rename" plugin or shortcut. This Guideline does not pretend otherwise. The alternative (no lock) is torn reads that pollute downstream specialist briefs in ways slow to catch and expensive to undo. Four taps to prevent that is a good trade. Users may automate via an OS-level Shortcut later; if so, the rule stays the same; only the gesture changes.

#### N.7.4 LLM behavior (session-start scan)

When the LLM scans `<needs_feedback_path>` at session start:

1. **List every file under every `<YYYY-MM-DD-title>/` subfolder.**
2. **Filter:** skip every file matching `*-IN-REVIEW.pdf`. These are locked.
3. **Of the remaining files**, for each `<file>.pdf`:
   - If `mtime > now - 60s`: log a one-line warning (`WARN: <path> modified <N>s ago, not -IN-REVIEW-flagged — possible un-flagged active annotation; deferring to next scan`). Do NOT process this round. Soft second-line defense.
   - Otherwise: read per §N.6 discipline; produce structured extract per §N.6.4; route to specialist(s).
4. **Report:** at the end of the scan, surface to <USER_NAME>: (a) count processed, (b) count of `-IN-REVIEW.pdf` skipped (with paths), (c) count of mtime-quiet-window warnings. The skipped + warned counts are visible so <USER_NAME> can spot a stale lock.

The mtime-quiet-window warning is a **soft** secondary check — it does NOT replace the primary rename lock.

#### N.7.5 When a file stays `-IN-REVIEW` too long (stale-lock detection)

A file that has been `*-IN-REVIEW.pdf` for **more than 72 hours** is presumed stale. At session start, the LLM surfaces these:

```
STALE LOCK: <path> has been -IN-REVIEW for <N>h. Confirm: still annotating, or rename back?
```

<USER_NAME> answers; the LLM never silently un-locks. The 72-hour threshold balances "user takes weekends off" against "lock genuinely forgotten." Tunable in `.handwritten-loop.yaml` later if annotation rhythm demands it.

#### N.7.6 Cross-references (the concurrency-safety pair)

- §N.6 (read-discipline) — pairs with this subsection. §N.7 says WHEN the LLM may read; §N.6 says HOW it reads once safe.
- §N.1 (forward direction) — placement of the rendered PDF. Files arrive WITHOUT the `-IN-REVIEW` suffix; <USER_NAME> adds the suffix when opening to annotate.
- §N.2 (reverse direction) — once annotation is complete and the file is renamed back, the LLM processes per §N.2 into `PKM/raw-footage/<subfolder>/YYYY/MM/` per [[file-naming-conventions]] §10.
- §N.3 (end-of-day rule) — both transient folders must be empty by end of day IF work was completed. A `-IN-REVIEW.pdf` file at end of day means either finish or rename back un-annotated. The lock does not exempt files from the end-of-day rule; it only prevents mid-day races.
```

---

## Worked example — the mirrored-folder placement convention

The convention's value is provenance. Concrete example (LLM may include this in the user's local Guideline as an inline "### N.X Worked example" subsection if useful, or keep it here as installer documentation only):

You have a Deliverables folder at:

```
Deliverables/2026-05-28-q3-strategy-plan/
├── plan.md
├── appendix-a-financials.md
└── appendix-b-team-shape.md
```

Two of these need your annotation: `plan.md` and `appendix-b-team-shape.md`. The render flow:

1. Render `plan.md` → `plan.pdf`. Copy to `<needs_feedback_path>/2026-05-28-q3-strategy-plan/plan.pdf`.
2. Render `appendix-b-team-shape.md` → `appendix-b-team-shape.pdf`. Copy to `<needs_feedback_path>/2026-05-28-q3-strategy-plan/appendix-b-team-shape.pdf`.
3. Both PDFs sit at the top of the SAME mirrored subfolder. No nested structure. You open your handwriting app, navigate to `2026-05-28-q3-strategy-plan/`, see both PDFs side by side, immediately know they're from the same deliverable.
4. You annotate `plan.pdf`. Before the first stroke, rename to `plan-IN-REVIEW.pdf` per §N.7.1. The LLM's next scan skips it; `appendix-b-team-shape.pdf` (untouched, no `-IN-REVIEW` suffix) gets processed if you're done with that one.
5. You finish `plan-IN-REVIEW.pdf`, rename back to `plan.pdf`. Next scan picks it up, reads the ink per §N.6, produces a structured extract per §N.6.4, routes the decisions to the right specialist.
6. After both PDFs are processed, the mirrored subfolder `2026-05-28-q3-strategy-plan/` is deleted. The transient folder `<needs_feedback_path>` returns to empty (modulo other in-flight deliverables).

The provenance lives in the subfolder name — `2026-05-28-q3-strategy-plan/` tells you instantly which Deliverables folder these came from. Without the mirror, you'd have two orphan PDFs at the root of `Needs Feedback/` and no context.

---

## Decisions log entry

```markdown
| <next-row-id> | <today> | §N (new) | Added §N Handwritten PDF placement convention (mirrored folders), §N.6 Reading annotated PDFs discipline (5-rule + 6-step checklist), §N.7 Lock convention for in-review PDFs (`*-IN-REVIEW.pdf` rename + 72h stale detection). Establishes the bidirectional PDF workflow: forward direction places renders at `<needs_feedback_path>/<YYYY-MM-DD-title>/<file>.pdf` mirroring the Deliverables folder name; reverse direction routes annotated PDFs through the read discipline into `PKM/raw-footage/` archive. | Installed by the Handwritten Collaboration Loop Expansion Pack v1.0.0. The workflow needs a placement convention, a read discipline (to prevent misreads of handwritten annotations), and a lock convention (to prevent torn reads mid-annotation). These three subsections together are the operational contract for the bidirectional PDF loop. |
```

---

## Rollback (for `teardown.md`)

To revert:

1. Find and delete the entire `## N. Handwritten PDF placement convention` section including all subsections N.1–N.7.6.
2. Remove the Decisions log row.
3. Tell the user: "Reverted the handwritten PDF placement, read-discipline, and lock convention sections from your `deliverable-formats` Guideline. Any deliverables currently mid-flight that use the `<needs_feedback_path>/<YYYY-MM-DD-title>/` placement will continue working at the filesystem level — the convention is just no longer documented in your Guideline. Your LLM may also forget to apply the lock convention after this revert; manual care required during the transition."
