# Handwritten Collaboration Loop

**Capture handwritten notes and sketches from any handwriting app into your myPKA. An LLM in the middle classifies, routes, and archives.**

You write by hand on your device of choice. The file syncs to a folder your LLM watches. Your LLM reads the ink (multimodal PDF reading), classifies the artifact (meeting note / sketch / strategy idea / voice memo / misc), and files it into your PKM under `PKM/raw-footage/<subfolder>/YYYY/MM/`.

In the reverse direction, deliverables your team produces get rendered to PDF and dropped where you can annotate them on the same device — annotations sync back, your LLM reads the ink, and decisions feed downstream work.

---

## Who this is for

myPKA users who:

- Capture meaningful thinking by hand on a tablet, e-ink device, or notes app.
- Want those captures to land in their PKM **without manual filing**.
- Run an LLM (Claude Code, Claude Desktop, Cursor, or any equivalent with multimodal PDF reading) as their orchestrator.
- Already have the base myPKA scaffold installed (Larry + Penn present).

If your capture is keyboard-only or voice-to-text, this Expansion is overkill — Penn already handles those routes via the standard journal capture workflow.

---

## What it does (one screen)

```
Your handwriting app                  Your LLM (orchestrator)             Your myPKA
─────────────────                     ──────────────────────              ──────────

  [ pen stroke ]
        ↓
  [ file syncs to ]                          ↓ session-start scan
  Send to team/             ─────────→   Larry reads the ink        ─────→ PKM/raw-footage/
        ↓                                Classifies the shape              <subfolder>/YYYY/MM/
  (PDF, sketch, voice note)              Routes to Penn                    <slug>.pdf + sidecar.md
                                              ↓
                                         Penn files + writes
                                         linked_raw_inputs back-pointer

  REVERSE DIRECTION (team → you):

  [ pen annotates ]
        ↑
  For Review/<title>/         ←──────  Charta renders deliverable  ←──── Deliverables/<title>/
  <file>.pdf                           to PDF, drops in mirrored            <file>.md
                                       subfolder
                                              ↑
                                       Your LLM reads annotations
                                       per the 5-rule discipline →
                                       structured extract → specialist
                                       gets the decisions
```

Five canonical raw-footage subfolders: `meetings/`, `sketches/`, `strategy-ideas/`, `voice-memos/`, `_misc/`. Date-nested `YYYY/MM/` under each.

---

## Prerequisites

1. **myPKA scaffold ≥ v1.7.0** with `Larry` and `Penn` in `Team/agent-index.md`.
2. **An LLM with multimodal PDF reading** (Claude Code, Claude Desktop, Cursor, or equivalent). If yours doesn't read PDFs natively, the onboarding flow detects it and offers an OCR sidecar (Tesseract or Apple Vision, both free).
3. **A handwriting app that syncs to a file-accessible folder.** Anything that writes files to a path your LLM can read. The onboarding flow branches on whether your app syncs INSIDE your myPKA (Mode A) or to an external sandbox (Mode B).

---

## Install in 3 steps

1. **Download the pack** — you'll get a `.zip` file.
2. **Unzip and drop the folder into the `Expansions/` directory** inside your myPKA.
3. **Ask Larry to install the expansion** — Larry reads the manifest, opens `ADAPT-EXPANSION.md`, walks you through the 7-question onboarding flow, and wires everything up.

That's the entire user-side install flow. No CLI script, no YAML hand-edit, no installer binary. Larry does the work; you answer questions.

Total install time: 10–15 minutes including the onboarding questions.

---

## Two modes (Larry picks one for you based on your app)

### Mode A — App syncs INSIDE your myPKA (preferred)

If your handwriting app can write directly to a folder inside your myPKA tree (Obsidian, Logseq, file-system-aware apps), the two transient folders live at `myPKA/Send to team/` and `myPKA/For Review/`. Zero workaround, fully local.

### Mode B — App syncs to an EXTERNAL sandbox

If your app sandboxes its sync location (PDF Expert, Apple Notes, GoodNotes, Notability, reMarkable), the two transient folders live at the path your app controls (e.g. `~/Library/Mobile Documents/<container>/Documents/`). Larry scans those external paths.

Both modes produce the same end state: raw artifacts archived in `PKM/raw-footage/`, downstream `.md` entries carrying `linked_raw_inputs:` back-pointers.

---

## Privacy posture (read before installing)

**Handwritten PDFs may contain sensitive content.** Meeting notes with names. Signed contracts. Medical sketches. Financial figures.

This Expansion does not move your PDFs over the network on its own. But the LLM you point at it does — every time it reads a PDF, the file content goes wherever your LLM provider sends it. Before installing:

1. **Confirm your LLM provider's data-handling posture.** Anthropic and OpenAI both publish data-retention and training-use policies. Verify yours matches your tolerance for the artifacts you'll capture.
2. **If you capture genuinely sensitive material** (medical, legal, financial-regulated), use the optional OCR sidecar — Tesseract or Apple Vision, both free, both run locally. The OCR sidecar extracts text; only the text reaches your LLM, never the raw PDF.
3. **The `_misc/` bucket is not a safe harbor.** Anything in `PKM/raw-footage/_misc/` is just as visible to your LLM as anything else.

Larry surfaces this posture as a hard gate during onboarding (Q7). No silent consent.

---

## Failure modes (when something breaks)

| Symptom | Likely cause | Fix |
|---|---|---|
| Larry says "I can't find Send to team/" | Mode B: iCloud hasn't synced; or app hasn't been launched on this Mac | Open the app once, wait for sync, retry |
| Sidecar `.md` written but no `linked_raw_inputs:` back-pointer | Frontmatter amendment didn't apply | Re-run the amend step from `ADAPT-EXPANSION.md` |
| Larry reads a half-annotated PDF | Lock convention skipped | Rename to `*-IN-REVIEW.pdf` BEFORE annotating; rename back when done |
| Duplicates appear on every scan | LLM copied instead of moving | Ask Larry to retry with explicit move semantics |
| Mode B paths broke after app update | Container path changed across major version | Re-run onboarding Q3 to capture the new path |

---

## Uninstall

Ask Larry: "uninstall the Handwritten Collaboration Loop."

Larry reverses the three Guideline amendments, archives `PKM/raw-footage/` to `PKM/_archive/raw-footage-<today>/` (does NOT delete — your data), removes the two transient folders (Mode A) or warns you to remove them manually from your app's sandbox (Mode B), and deletes `.handwritten-loop.yaml`. Symmetric. Reversible. Your data survives.

---

## License

Proprietary. Distributed via app.myicor.com to paying members (Inner Circle / Lifetime / Monthly tiers). Author it freely for your own use inside your own myPKA; no redistribution.

---

## Where to start

Drop this folder into your myPKA's `Expansions/` directory and ask Larry to install. Larry takes it from there.
