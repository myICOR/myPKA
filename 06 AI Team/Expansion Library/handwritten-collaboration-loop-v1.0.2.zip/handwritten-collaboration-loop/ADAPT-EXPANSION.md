# ADAPT-EXPANSION — Handwritten Collaboration Loop

**Audience: the LLM installing this Expansion (Larry, or the user's orchestrator equivalent).** This file is your operating manual. The user does not read this; they read `README.md`. You read this top-to-bottom and execute.

---

## 0. Pre-flight (do this before asking the user anything)

1. Confirm you are running inside a myPKA scaffold: `AGENTS.md` exists at the cwd root AND `PKM/` exists AND `Team Knowledge/` exists. If any is missing, stop and tell the user: "This Expansion installs into a myPKA scaffold — I don't see one at `<cwd>`. Confirm your myPKA root path or install myPKA first."
2. Confirm `Larry` and `Penn` are present in `Team/agent-index.md`. If either is missing, stop and tell the user which to install first (point them at `SOP-001-how-to-add-a-new-specialist`).
3. Check whether `.handwritten-loop.yaml` already exists at the myPKA root. If yes, this is a re-install — ask the user: "I see a previous config. Overwrite (re-run onboarding) or re-use (skip to install)?" Branch accordingly.
4. Read `README.md` so you can answer user questions in their voice. Do not lecture them about principles during onboarding.

Voice for the entire flow: helpful, clear, plain language. Honest about app limitations (Apple Notes is a known hard case — don't promise an easy outcome). Never silently default; if the user skips, tell them what you defaulted to.

---

## 1. Onboarding — the 7-question flow

Walk Q1 through Q7 in order. Branch where the question tells you to. Capture every answer; at the end, write them all to `.handwritten-loop.yaml`.

### Q1 — Which handwriting or note-taking app do you use?

**Ask the user (literal):**

> Which app do you use to capture handwritten notes, sketches, or annotations? Common ones I can configure: PDF Expert, Apple Notes, GoodNotes, Notability, Obsidian, Logseq, reMarkable. If yours isn't on that list, just tell me the name — I'll do my best.

**Branch logic — set `app:` and likely mode:**

| User says | `app:` slug | Likely mode | Next |
|---|---|---|---|
| Obsidian | `obsidian` | Mode A | Q2 (confirm) |
| Logseq | `logseq` | Mode A | Q2 (confirm) |
| PDF Expert | `pdf-expert` | Mode B | Q2 (confirm) |
| Apple Notes | `apple-notes` | Mode B + caveat | Q2 (confirm + warn) |
| GoodNotes | `goodnotes` | Mode B | Q2 (confirm) |
| Notability | `notability` | Mode B (usually) | Q2 (diagnostic) |
| reMarkable | `remarkable` | Mode B (unusual) | Q2 (rmapi check) |
| anything else | `other` + free-text label | unknown | Q2 (full diagnostic) |

**Default if user skips:** ask once more — this is the one question you cannot guess. If they still skip, stop the install and tell them they need to know their capture app before proceeding.

### Q2 — Can your app sync to a folder INSIDE your myPKA tree?

This determines Mode A vs Mode B. Mode A is preferred (zero workaround, lower friction).

**For known Mode A apps (Obsidian, Logseq):**

> Good — `<app>` lets you choose any folder as its vault/working directory. We'll point it at a folder inside your myPKA. That's Mode A — the lowest-friction setup. Sound right?

→ set `mode: A`, skip Q3, continue to Q4.

**For known Mode B apps (PDF Expert, Apple Notes, GoodNotes, reMarkable):**

> `<app>` syncs to its own sandboxed folder — you can't redirect it into your myPKA tree. That's fine; we'll use Mode B, where the transient folders live in the app's sandbox and I scan that location at session start. Sound right?

→ set `mode: B`, continue to Q3.

**Edge cases (read aloud to user):**

- **Apple Notes:** "Apple Notes is the hardest app to integrate. Its notes live in a SQLite database, not a user-accessible folder. The cleanest path: export specific notes as PDF to a folder I can read. You'll need to manually export the notes you want me to see. Proceed, or switch apps?" If proceed → `mode: B`, set `notes.apple_notes_caveat: true`.
- **reMarkable:** "reMarkable only syncs via their paid Connect subscription or the third-party `rmapi` CLI. Do you have `rmapi` installed and authenticated? (Run `which rmapi` to check.)" If yes → `mode: B`, `notes.remarkable_uses_rmapi: true`. If no → stop, tell user to install `rmapi` first.

**For Notability or "other" — run the diagnostic:**

Ask three questions:
1. Does your app have a "Sync to folder" / "Vault" / "Working directory" setting? (Yes → likely Mode A; No → likely Mode B)
2. (If yes) Can the sync target be set to an arbitrary folder you choose, including a folder inside your myPKA? (Yes → confirmed Mode A; No → Mode B with a specific cloud folder)
3. (If Mode B) Where does the app sync? Find the absolute path. For iCloud apps the path is almost always `~/Library/Mobile Documents/iCloud~<vendor>~<app>/Documents/` — ask the user to open Finder → iCloud Drive → app folder → right-click → "Show in Finder" → copy the path.

Set `mode:` accordingly and continue.

### Q3 — (Mode B only) Where does your app sync files?

**Skip if `mode: A`.**

> I need the absolute path where `<app>` syncs its files. That's where I'll create your `Send to team/` and `For Review/` folders.

**Worked examples (offer based on `app:`):**

| App | Typical absolute path |
|---|---|
| PDF Expert | `~/Library/Mobile Documents/3L68KQB4HG~com~readdle~CommonDocuments/Documents/` |
| GoodNotes | `~/Library/Mobile Documents/iCloud~com~time-base~handwriting/Documents/` (varies by version) |
| Notability | `~/Library/Mobile Documents/iCloud~com~gingerlabs~notability/Documents/` |
| reMarkable (via rmapi) | wherever `rmapi` mirrors files — user-chosen |
| Apple Notes | NOT FILE-ACCESSIBLE; user picks an iCloud Drive folder for manual PDF exports |

**Validate:**

1. Check the path exists on disk (`ls` it).
2. If not: for iCloud apps tell user "the iCloud container isn't present — open `<app>` once on this Mac, let it sync, then retry." For free-text paths: ask the user to confirm.
3. If exists but not writable: stop and tell the user.

**Default if user can't provide a path:** stop. Mode B without an external sync path is not installable.

**ABSOLUTE PATHS ONLY.** No `~`, no relative paths — resolve them before writing to config.

### Q4 — What names do you want for the two transient folders?

> Two transient folders sit at the heart of this workflow: one where YOU drop things for the team to pick up, and one where the team drops things for YOU to review. Defaults are `Send to team/` (you → team) and `For Review/` (team → you). Use defaults, or customize?

**Validate:** both non-empty, different from each other, no `/`, `\`, `:` characters.

**Default:** `Send to team` and `For Review`. Always tell the user what you defaulted to.

### Q5 — Which raw-input sub-folders do you want under `PKM/raw-footage/`?

> When files leave the transient folders and land in their permanent home, they go into `PKM/raw-footage/<subfolder>/YYYY/MM/`. Defaults are `meetings`, `sketches`, `strategy-ideas`, `voice-memos`, and `_misc` (the catch-all). Keep defaults, add custom ones, or remove any?

**Validate each name** (per `[[file-naming-conventions]]` §10): kebab-case ASCII, lowercase, letters/digits/hyphens only, starts with a letter. The `_misc` underscore prefix is the one documented exception — preserve it.

**Never drop `_misc`.** If the user tries to remove it, tell them why it stays.

### Q6 — Multimodal LLM check + optional free OCR sidecar

> The handwriting-read step depends on me being able to read PDF content directly — including handwritten ink. I'm running on `<LLM-tool-the-user-uses>`. Can I read PDFs natively?

Branch:
- Claude Code / Claude Desktop / Anthropic → `multimodal: yes`, `needs_ocr_sidecar: false`.
- ChatGPT / OpenAI → `multimodal: yes-with-limits` (no folder-scan automation), warn user.
- Cursor / Aider / Other → ask user to check; default to `unknown` and offer the OCR sidecar.

**OCR sidecar offer (only when `multimodal != yes`, OR if user opts in for privacy):**

> I can wire up a free OCR sidecar so handwriting gets converted to text locally before any LLM sees it. Two free options:
> - **Apple Vision** (macOS only, built-in) — no install required, runs on-device, very good at handwriting.
> - **Tesseract** (cross-platform, open source) — install via `brew install tesseract` on macOS or your package manager on Linux/Windows. Good at print, decent at handwriting.
>
> Want me to set one up? Both are free; both stay local.

If user says yes → set `ocr_sidecar: apple-vision` OR `ocr_sidecar: tesseract`. Write a brief invocation contract into `.handwritten-loop.yaml` (which binary to call, where to drop the extracted text). Skip if the user declines or has no need.

**Never offer paid OCR APIs in v1.** Tom's rule (D-open-1): free only.

### Q7 — Privacy posture confirmation (HARD GATE)

This is a gate, not a question. Do not write the config or hand off until the user explicitly acknowledges.

> Before I finalize: PDFs in your transient folders may contain sensitive content — contracts, medical notes, signatures, client information, financial data. Every time I scan, your LLM provider sees the file contents. For Anthropic and OpenAI, that means the file passes through their API.
>
> Confirm:
> 1. You understand your LLM provider is `<provider>` and the privacy implications.
> 2. You are responsible for not dropping content into these folders that your provider's terms don't allow.
> 3. If you have content too sensitive: use the OCR sidecar (local-only), or process it manually outside this workflow.

**No default. Silence is not consent.** If user says no/wait → stop, tell them they can re-run once ready.

---

## 2. Write `.handwritten-loop.yaml`

After Q7 acknowledgement, write the assembled config to `<user's myPKA root>/.handwritten-loop.yaml`. Use `config-template.handwritten-loop.yaml` (shipped in this Expansion folder) as the schema. Fill every field; do not leave placeholders.

Show the user a plain-language summary, ask "Proceed with install?", and do NOT continue until they confirm.

---

## 3. Install — execute in order

### 3.1 Create `PKM/raw-footage/` + the five subfolders

Run `SOPs/SOP-create-transient-folders.md` §1 (raw-footage subfolders). Per `[[file-naming-conventions]]` §10. If any subfolder already exists with content, leave it; log a note.

### 3.2 Create the two transient folders (mode-branched)

Run `SOPs/SOP-create-transient-folders.md` §2.

- **Mode A (`mode-a-internal`):** create the inbound folder at `team_inbox_path` and the outbound folder at `needs_feedback_path` (defaults: `Send to team/` and `For Review/` at the myPKA root).
- **Mode B (`mode-b-external`):** create the inbound folder at `team_inbox_path` and the outbound folder at `needs_feedback_path` — the app's external sandbox paths captured in Q3. Verify both folders are visible in the user's app (user opens the app, refreshes, confirms).

### 3.3 Apply the three Guideline amendments

Run `SOPs/SOP-amend-local-guideline.md` for each amendment file in `guidelines-amendments/`:

1. `GL-amendment-file-naming-conventions.md` → applies to user's local `[[file-naming-conventions]]` Guideline.
2. `GL-amendment-frontmatter-conventions.md` → applies to user's local `[[frontmatter-conventions]]` Guideline.
3. `GL-amendment-deliverable-formats.md` → applies to user's local `[[deliverable-formats]]` Guideline.

**Match on slug, not on number.** The user's GL numbering may diverge from the canonical scaffold (e.g. their `file-naming-conventions` could be `GL-007` instead of `GL-001`). The amendment files are slug-keyed precisely to absorb this drift.

Each amendment has its own preflight (does the target exist? is the section already present from a prior install?) and rollback note. If an amendment can't apply cleanly, stop and tell the user — do not silently skip.

### 3.4 Install the operational Workstream

Auto-renumber per `[[file-naming-conventions]]` §6:

1. Scan `Team Knowledge/Workstreams/` for the highest existing `WS-NNN`.
2. Copy `Workstreams/WS-handwritten-collaboration-loop.md` from this Expansion to `Team Knowledge/Workstreams/WS-<next-free-NNN>-handwritten-collaboration-loop.md`.
3. Update `Team Knowledge/Workstreams/INDEX.md`.
4. Body uses slug-only `[[wikilinks]]` — do NOT rewrite to add GL-NNN prefixes; that breaks cross-numbering tolerance.

If a Workstream with the same slug exists, stop and ask.

### 3.5 Install the raw-input sidecar template

1. Copy `Templates/raw-input-sidecar-template.md` to `Team Knowledge/Templates/raw-input-sidecar-template.md`.
2. Update `Team Knowledge/Templates/INDEX.md`.

If template already exists, stop and ask.

### 3.6 Regenerate `mypka.db` if present

If `mypka.db` exists at the myPKA root, the GL-002 amendment changed the schema (new `raw_input` doc_type, new `linked_raw_inputs` cross-entity field). Regen.

Run: `python3 "Team Knowledge/scripts/regen-mypka-db.py"` per `[[SOP-002-convert-mypka-to-sqlite]]`. Idempotent.

If `mypka.db` doesn't exist, skip with a note.

### 3.7 Smoke test (round-trip)

Run `SOPs/SOP-scan-and-route-raw-input.md`:

1. Ask the user to drop a one-page handwritten test PDF in their configured `Send to team/` (or sample one yourself from `examples/sample-raw-input-meeting-note.md`).
2. Scan the folder; classify the file; file it under `PKM/raw-footage/<subfolder>/YYYY/MM/<slug>.pdf`.
3. Write a sidecar `.md` next to the PDF with `raw_input` frontmatter populated (slug, doc_type, source, raw_format, captured_at, received_at, processing_status, subfolder).
4. Route to Penn; Penn writes the downstream entity (journal entry, project note) with `linked_raw_inputs:` back-pointer to the sidecar.
5. **In Mode B:** verify the LLM MOVED (not copied) the source PDF. The external `Send to team/` should be empty after processing.

If all five happen, the loop is live. Tell the user.

### 3.8 Write the install session-log entry

Per WS-003 §7: `Team Knowledge/session-logs/YYYY/MM/YYYY-MM-DD-HH-MM_larry_install-handwritten-collaboration-loop-v1.0.md`. Capture: mode chosen, app, configured paths, folders created (with auto-numbered slots), amendments applied, mypka.db status, smoke-test result.

---

## 4. Operating contract (post-install — what to do on every session start)

Once installed, you run the workflow per `Team Knowledge/Workstreams/WS-<NNN>-handwritten-collaboration-loop.md`. The Workstream is now canonical; do not refer back to this ADAPT file for steady-state operation. Steady-state condensed:

1. **Session start:** scan `<team_inbox_path>` and `<needs_feedback_path>` (read from `.handwritten-loop.yaml`).
2. **For each new file in `<team_inbox_path>`:** classify (meeting / sketch / strategy-idea / voice-memo / misc), MOVE to `PKM/raw-footage/<subfolder>/YYYY/MM/<slug>.pdf`, write sidecar `.md` with `raw_input` frontmatter, route to the right specialist (Penn for journals, Iris for design-related sketches, Felix for app mockups, etc.), have them write the downstream entity with `linked_raw_inputs:` back-pointer.
3. **For each new annotated PDF in `<needs_feedback_path>`:** read the annotations per the 5-rule discipline (see amended `[[deliverable-formats]]` §8.6), extract decisions, route back to the deliverable's owning specialist, file the annotated PDF under `_archive/`.
4. **Honor the lock convention:** skip any file matching `*-IN-REVIEW.pdf` (user is actively annotating). Flag stale locks (>72h, configurable) at session start.

---

## 5. Failure handling

| Situation | Behavior |
|---|---|
| User's myPKA root missing | Stop; tell user. Don't guess. |
| `Larry` or `Penn` missing from agent-index | Stop; point at SOP-001-how-to-add-a-new-specialist. |
| Amendment target Guideline missing | Tell user the slug we expected; ask if they have it under a different name or want to skip that amendment (degraded install). |
| Amendment section already present (prior install or manual edit) | Skip cleanly; log to session-log. Do NOT duplicate. |
| Workstream slug collision | Stop; ask user whether to overwrite or pick a new slug. |
| `mypka.db` regen script missing (older scaffold) | Skip with a note; user can regen later. |
| Mode B path doesn't exist after install | Tell user to open the app once and let it sync; retry validation. |

Never proceed past a failure silently. The Expansion is small; a clean re-run is cheap.

---

## 6. Uninstall (when user asks "uninstall the Handwritten Collaboration Loop")

1. Preflight: read `.handwritten-loop.yaml`, summarize what will happen, ask the user `[y/n/inspect]`.
2. Remove the Workstream from `Team Knowledge/Workstreams/`; remove the INDEX row. Do NOT renumber other Workstreams (gap is acceptable per WS-003 §U3).
3. Remove the raw-input sidecar template; remove the INDEX row.
4. Revert each Guideline amendment per its own "Rollback" section in `guidelines-amendments/<file>.md`.
5. **Archive `PKM/raw-footage/` to `PKM/_archive/raw-footage-<today>/`.** Do NOT delete. User data is preserved.
6. **Mode A:** remove `Send to team/` and `For Review/` at myPKA root (warn if non-empty).
   **Mode B:** do NOT touch the external sandbox; tell the user to remove the folders manually from the app.
7. Delete `.handwritten-loop.yaml` (confirm with user first).
8. Regen `mypka.db` if present (drops `raw_inputs` table since schema no longer defines it).
9. Write the uninstall session-log entry.
10. Move `Expansions/handwritten-collaboration-loop/` to `Expansions/_uninstalled/handwritten-collaboration-loop-1.0.0/`.

Symmetric. Reversible. The user's data survives.

---

## 7. References (LLM, follow these wikilinks at install time against the user's local Guidelines)

- `[[file-naming-conventions]]` — §10 raw-footage convention (added by GL amendment 1)
- `[[frontmatter-conventions]]` — `raw_input` doc_type + `linked_raw_inputs` field (added by GL amendment 2)
- `[[deliverable-formats]]` — §8 handwritten PDF placement + §8.6 read discipline + §8.7 lock convention (added by GL amendment 3)
- `[[WS-003-install-an-expansion]]` — the install workstream that drives this whole flow
- `[[SOP-002-convert-mypka-to-sqlite]]` — the regen script (only relevant if user has mypka.db)
