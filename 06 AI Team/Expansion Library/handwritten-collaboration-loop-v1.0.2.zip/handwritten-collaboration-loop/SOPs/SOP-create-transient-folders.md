---
slug: create-transient-folders
doc_type: sop
default_owner: Larry
purpose: Create raw-footage canonical subfolders + the two transient working folders (Mode A or Mode B).
expansion: handwritten-collaboration-loop
---

# SOP — Create transient folders

Atomic procedure invoked from `ADAPT-EXPANSION.md` §3.1 and §3.2. Mode-branching at §2.

---

## §1. Create `PKM/raw-footage/` + five canonical subfolders

Per `[[file-naming-conventions]]` §10 (added by this Expansion's GL amendment).

1. `mkdir -p PKM/raw-footage/meetings`
2. `mkdir -p PKM/raw-footage/sketches`
3. `mkdir -p PKM/raw-footage/strategy-ideas`
4. `mkdir -p PKM/raw-footage/voice-memos`
5. `mkdir -p PKM/raw-footage/_misc`

If any of the five already exists and is non-empty, log a one-line note (`note: PKM/raw-footage/<sub>/ already exists with N files; left untouched`) and do not delete, move, or rename anything.

Do NOT create `YYYY/MM/` subfolders pre-emptively. Penn creates those at filing time per the date-folder rule in the root `AGENTS.md` §5.

The leading underscore on `_misc/` is deliberate (sorts to top, signals "bucket"). This is the documented exception to the kebab-case folder rule in `[[file-naming-conventions]]`. Do not normalize to `misc/`.

---

## §2. Create the two transient folders (mode-branched)

Read `mode:`, `team_inbox_path:`, and `needs_feedback_path:` from `.handwritten-loop.yaml`. Both paths are absolute in every mode. In `mode-a-internal` they point inside the myPKA tree (defaults: `Send to team` and `For Review` at the root); in `mode-b-external` they point at the handwriting app's external sandbox.

### §2.A — `mode-a-internal`

1. `mkdir -p "<team_inbox_path>"` (the inbound folder; default `<myPKA_root>/Send to team`).
2. `mkdir -p "<needs_feedback_path>"` (the outbound folder; default `<myPKA_root>/For Review`).
3. If either already exists and is non-empty, log a note and leave content alone. Many scaffolds ship a `Team Inbox/` — this SOP re-uses, does not replace.

### §2.B — `mode-b-external`

1. `mkdir -p "<team_inbox_path>"` (the app's external inbound sandbox path).
2. `mkdir -p "<needs_feedback_path>"` (the app's external outbound sandbox path).
3. Verify both folders are visible in the user's app. Ask the user to open their app, refresh (close+reopen or pull-to-refresh on iOS), and confirm both folders appear.
4. If the app's container path doesn't exist (e.g. user hasn't launched the app yet on this Mac), stop and tell them to open the app once, let iCloud sync, then retry.

---

## §3. Validation

After §1 and §2:

- All five subfolders under `PKM/raw-footage/` exist.
- Both transient folders exist at the path appropriate to the user's mode.
- The folders are writable by the LLM's process.

Report all paths created (or noted as pre-existing) back to ADAPT-EXPANSION §3.

---

## §4. Rollback

If a later install step fails and the user wants to abort:

- Mode A: `rmdir` both transient folders if empty.
- Mode B: tell user to delete the external folders manually via their app.
- `PKM/raw-footage/` subfolders: leave in place if non-empty; `rmdir` if empty AND the user explicitly asks for full revert.
