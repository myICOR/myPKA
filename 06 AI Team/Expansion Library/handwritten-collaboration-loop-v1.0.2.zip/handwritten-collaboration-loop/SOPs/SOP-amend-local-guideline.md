---
slug: amend-local-guideline
doc_type: sop
default_owner: Larry
purpose: Apply an LLM-readable amendment to one of the user's existing Guidelines, matching on slug (not on local number).
expansion: handwritten-collaboration-loop
---

# SOP — Amend a local Guideline

Atomic procedure invoked from `ADAPT-EXPANSION.md` §3.3. Called once per amendment file in `guidelines-amendments/`.

---

## §1. Inputs

- `amendment_file` — absolute path to the amendment instruction file (e.g. `guidelines-amendments/GL-amendment-file-naming-conventions.md`).
- The amendment file declares its `target_slug` in its frontmatter (e.g. `target_slug: file-naming-conventions`).

---

## §2. Resolve the target Guideline

The user's local Guideline numbering may differ from the canonical myICOR scaffold. ALWAYS match on slug:

1. Read `target_slug` from the amendment file's frontmatter.
2. Scan `Team Knowledge/Guidelines/` for files matching `GL-*-<target_slug>.md` (regex: `^GL-\d+-<target_slug>\.md$`).
3. If exactly one match: that's the target.
4. If zero matches: stop. Tell the user: "I expected a Guideline with slug `<target_slug>` but didn't find one. Do you have it under a different name, or should I skip this amendment (degraded install)?"
5. If multiple matches: stop. Tell the user; ask them to disambiguate.

---

## §3. Preflight (is the amendment already applied?)

The amendment file declares a `marker_string` (e.g. a section heading like `## 10. Raw-footage subfolder convention`) that uniquely identifies the section it adds.

1. Read the target Guideline.
2. Search for `marker_string`.
3. If found: the amendment is already applied (prior install, manual edit, or partial install). Log to session-log; skip. Do NOT duplicate.
4. If not found: proceed to §4.

---

## §4. Apply the amendment

The amendment file has two sections:

- `## Section to insert` — the verbatim markdown to add to the target Guideline.
- `## Insertion point` — where to insert it (typically "append to end of body, before the Decisions log" or "at section N").

LLM action:

1. Read both sections from the amendment file.
2. Open the target Guideline.
3. Insert the verbatim markdown at the declared insertion point.
4. Append a row to the target Guideline's Decisions log (table at the bottom of the file): date, change description, source (this Expansion's slug + version).
5. Save.

---

## §5. Validation

After §4:

- The `marker_string` now appears in the target Guideline.
- The Decisions log has the new row.
- The file is well-formed markdown (no broken frontmatter, no orphan section markers).

---

## §6. Rollback

The amendment file's own body contains a `## Rollback` section describing the inverse operation (typically: "remove the section between `marker_string` and the next top-level heading; remove the matching row from the Decisions log").

Invoke this section at uninstall time (ADAPT-EXPANSION §6 step 4).

If the rollback can't apply cleanly (user manually edited the section after install), stop and tell the user:

> "The `<target_slug>` amendment can't be cleanly reverted — it looks like the section has been edited since install. I'll skip the auto-revert. To finish uninstall, please edit the Guideline by hand: find the section starting with `<marker_string>` and ending at the next top-level heading, delete that range, and remove the corresponding row from the Decisions log."

---

## §7. Notes

- Amendment files are slug-keyed, not number-keyed, on purpose. The user's `file-naming-conventions` Guideline might be `GL-001`, `GL-007`, or anything else; this SOP absorbs that drift.
- Never auto-renumber the user's Guidelines. Just amend the body.
- Never edit Guidelines OTHER than the declared `target_slug`. One amendment file = one target.
