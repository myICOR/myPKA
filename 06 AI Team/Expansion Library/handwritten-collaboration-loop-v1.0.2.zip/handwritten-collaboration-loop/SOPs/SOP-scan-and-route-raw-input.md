---
slug: scan-and-route-raw-input
doc_type: sop
default_owner: Larry
purpose: Scan the inbound transient folder, classify each new file, file it under PKM/raw-footage/, write the sidecar, route to the right specialist.
expansion: handwritten-collaboration-loop
---

# SOP — Scan and route raw input

Atomic procedure invoked on every session start (and on-demand when the user says "scan the inbox"). Drives the forward direction of the loop.

---

## §1. Read config

Load `.handwritten-loop.yaml` from the myPKA root. Read:

- `mode` (`mode-a-internal` | `mode-b-external`)
- `team_inbox_path` (absolute path to the inbound folder)
- `subfolders`
- `ocr_sidecar` (if `enabled`, use the OCR sidecar contract instead of multimodal read)
- `lock_suffix` (default `-IN-REVIEW`)

The inbound scan path (`<inbound_path>` below) IS `team_inbox_path` — an absolute path in both modes. In `mode-a-internal` it points at a folder inside the myPKA tree; in `mode-b-external` it points at the handwriting app's external sandbox (typically inside iCloud). No join is needed — read the path directly.

---

## §2. List candidate files

`ls` the inbound path. Apply filters:

1. Skip directories (the loop processes files, not folders).
2. Skip any file matching `*<lock_suffix>.*` (user is actively annotating).
3. Skip dotfiles (`.DS_Store`, `.~lock.*`, etc.).
4. Skip files with mtime within the last 60 seconds (mtime-quiet-window — file may still be syncing).

Remaining files are processing candidates.

---

## §3. For each candidate — classify

Read the file via your multimodal LLM capability (or call the OCR sidecar when `ocr_sidecar: enabled`).

Classify into one of the five raw-footage subfolders:

| Shape | Goes to | Heuristics |
|---|---|---|
| Meeting note | `meetings/` | Header lists attendees + date + agenda items |
| Sketch / diagram / wireframe | `sketches/` | Predominantly visual: arrows, boxes, hand-drawn shapes |
| Strategy idea / braindump | `strategy-ideas/` | Free-form ideation, lists of options, exploratory writing |
| Voice memo transcript | `voice-memos/` | Comes from an audio source; long-form spoken-style prose |
| Anything ambiguous | `_misc/` | Default catch-all; never block on classification |

When in doubt → `_misc/`. The bucket exists to prevent processing stalls.

---

## §4. File the artifact

For each candidate:

1. Compute the slug: `<YYYY-MM-DD>-<kebab-case-summary>` (e.g. `2026-05-28-mockup-collaboration-loop-iteration-3`). Use `received_at` date if `captured_at` unknown.
2. Resolve the destination: `PKM/raw-footage/<subfolder>/<YYYY>/<MM>/<slug>.<ext>`.
3. `mkdir -p` the `YYYY/MM/` if missing.
4. **MOVE** the file (not copy). Mode B especially: the external folder must end up empty for end-of-day discipline.
5. If cross-filesystem (Mode B common case), use copy-then-delete-source as a two-step.

---

## §5. Write the sidecar `.md`

Next to the moved binary, write `<slug>.md` populated from the `raw-input-sidecar-template.md` template:

```yaml
---
slug: <slug>
doc_type: raw_input
source: <handwriting app from .handwritten-loop.yaml>
raw_format: <pdf|jpg|png|m4a|...>
captured_at: <ISO timestamp inferred from filename or file mtime>
received_at: <ISO timestamp of this scan>
processing_status: pending
subfolder: <one of: meetings | sketches | strategy-ideas | voice-memos | _misc>
linked_processed_outputs: []
---
```

Body: brief one-paragraph summary of what the LLM read (so future scans / searches surface this artifact without re-reading the binary).

---

## §6. Route to the right specialist

Based on subfolder:

| Subfolder | Route to | Why |
|---|---|---|
| `meetings/` | Penn | Journal capture lives in Penn's domain |
| `sketches/` | Iris (design-related) OR Felix (app mockups) OR Penn (everything else) | LLM judgment per sketch content |
| `strategy-ideas/` | Penn (capture) → escalate to relevant project owner | Captured as Topic note, then linked |
| `voice-memos/` | Penn | Same as meetings |
| `_misc/` | Penn (default), with a note flagging "I couldn't classify — please route" | Never silently file-and-forget |

The receiving specialist writes the downstream entity (journal entry, project note, topic) and adds `linked_raw_inputs: [<slug>]` to that entity's frontmatter — back-pointer per the GL-002 amendment.

---

## §7. Update sidecar with the back-link

Once the receiving specialist has filed the downstream entity, update the sidecar's `linked_processed_outputs:` field with the vault-relative path to the downstream entity's `.md`. Bidirectional lineage — the downstream entity carries the reverse pointer in `linked_raw_inputs:` per the GL-002 amendment.

---

## §8. Report back to user

After processing all candidates:

> Scanned `<inbound_path>`. Processed N files:
> - `<slug-1>` → `meetings/` → Penn wrote journal entry `<entity-slug-1>`
> - `<slug-2>` → `sketches/` → Iris wrote design note `<entity-slug-2>`
> - ...
>
> M files skipped (locked / too recent / dotfile).

If any candidate failed mid-processing, surface the failure with the file path and the reason. Never silently drop.
