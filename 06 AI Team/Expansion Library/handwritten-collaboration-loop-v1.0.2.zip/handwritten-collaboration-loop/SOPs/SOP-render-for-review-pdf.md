---
slug: render-for-review-pdf
doc_type: sop
default_owner: Larry
purpose: Render a deliverable to PDF and drop it in the For Review/ outbound folder for the user to annotate.
expansion: handwritten-collaboration-loop
---

# SOP — Render a deliverable for handwritten review

Atomic procedure invoked when a specialist (Iris, Penn, Charta, etc.) declares a deliverable "ready for Tom's review" AND Tom's standing preference is handwritten annotation.

This drives the REVERSE direction of the loop (team → user).

---

## §1. Read config

Load `.handwritten-loop.yaml`. Read:

- `mode` (`mode-a-internal` | `mode-b-external`)
- `needs_feedback_path` (absolute path to the outbound folder)

The outbound path (`<outbound_path>` below) IS `needs_feedback_path` — an absolute path in both modes. In `mode-a-internal` it points at a folder inside the myPKA tree; in `mode-b-external` it points at the handwriting app's external sandbox. No join is needed — read the path directly.

---

## §2. Render the deliverable to PDF

The deliverable is a `.md` file under `Deliverables/<YYYY-MM-DD-title>/`. Render the source markdown to PDF.

Tool-agnostic: use whichever PDF rendering capability the user's setup has (Pandoc, weasyprint, Chrome headless, the user's own export tooling). The amended `[[deliverable-formats]]` §9.9 (added by GL amendment 3) declares the standard rendering parameters; honor those.

Output: `<deliverable-title>.pdf` (matches the source `.md` filename, swap extension).

---

## §3. Drop in the mirrored subfolder

Per the placement convention in amended `[[deliverable-formats]]` §8:

1. `mkdir -p "<outbound_path>/<YYYY-MM-DD-deliverable-title>"` (mirrors the Deliverables folder shape).
2. Copy the rendered PDF into that subfolder.
3. Set the file mtime to "now" so the user's app sees it as new.

Do NOT drop multiple deliverables in the same `<outbound_path>/<title>/` subfolder — one deliverable = one subfolder = one PDF (plus its annotated counterpart, later).

---

## §4. Notify the user

Tell the user:

> Rendered `<deliverable-title>` for your review. Dropped at:
> `<outbound_path>/<YYYY-MM-DD-deliverable-title>/<title>.pdf`
>
> When you're ready to annotate: open in your app, rename to `<title>-IN-REVIEW.pdf` BEFORE the first stroke (lock convention — I'll skip the file while you're annotating), annotate, then rename back to `<title>.pdf` when done.

---

## §5. Handoff to the inbound scan

Once the user finishes annotating and renames back to `<title>.pdf`:

- Larry's next scan of `<outbound_path>` (per session-start scan, or on-demand) detects the annotated PDF.
- Larry reads annotations per the 5-rule discipline in amended `[[deliverable-formats]]` §8.6:
  1. Read ink + typed annotations together.
  2. Extract decisions as discrete bullets, attributed to the page they're on.
  3. Cross-reference annotated lines back to the source `.md` lines.
  4. Surface ambiguities (illegible ink, contradicting marks) as questions, not assumptions.
  5. Write the structured extract to the deliverable's `Deliverables/<title>/decisions.md` (or update the deliverable's frontmatter `status:` to `decisions-locked` and append a Decisions section).
- The annotated PDF moves to `Deliverables/<title>/_archive/<title>-annotated-<YYYY-MM-DD>.pdf` as an audit trail.
- The outbound folder's `<title>/` subfolder is removed (end-of-day clean).

---

## §6. Failure modes

| Situation | Behavior |
|---|---|
| Rendering tool not installed | Surface to user; fall back to a different renderer if available; skip render and tell user to render manually |
| Mode B sync hasn't reached the user's device | Tell user; ask them to wait for sync or open the app to force-refresh |
| User edits the deliverable while reviewing (concurrent write) | The lock convention exists for this reason; if the user skipped the rename, surface the conflict and ask which version to keep |
| User leaves `-IN-REVIEW` for >72h (stale lock threshold) | Flag at session start: "this file has been -IN-REVIEW for X hours; is review still active?" |
