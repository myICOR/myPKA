---
slug: <YYYY-MM-DD>-<kebab-summary>
doc_type: raw_input
source: <handwriting-app-slug>           # pdf-expert | obsidian | goodnotes | etc.
raw_format: <pdf|jpg|png|m4a|other>
captured_at: <ISO timestamp; user's device clock when ink hit paper>
received_at: <ISO timestamp; when Larry's scan moved the file into raw-footage>
processing_status: <pending|classified|processing|processed|archived>
subfolder: <meetings|sketches|strategy-ideas|voice-memos|_misc>
linked_processed_outputs: []             # vault-relative paths to downstream .md entries this raw input produced
---

# <Human-readable title>

One-paragraph summary of what the artifact contains. This is what future scans and SQLite queries will see without re-reading the binary. Keep it dense — enough that a search for "kanban dashboard sketch" surfaces this sidecar without false negatives.

## Context

Where this came from (which meeting, which app session, which prompt). Who else was present. What problem it addresses.

## Routed to

`<specialist-name>` — `<one-sentence reason this specialist owns the downstream work>`.

## Downstream entities

Filled in by the receiving specialist once they've written the downstream note. Mirrors `linked_processed_outputs:` in the frontmatter; humans can read this without parsing YAML. The downstream entity carries the reverse pointer in its `linked_raw_inputs:` frontmatter, per the GL-002 amendment.

- `[[<downstream-entity-slug>]]` — `<short label>`
